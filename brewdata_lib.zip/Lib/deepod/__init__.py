from deepod.version import __version__
from . import core, models

__all__ = ['__version__', 'core', 'models']