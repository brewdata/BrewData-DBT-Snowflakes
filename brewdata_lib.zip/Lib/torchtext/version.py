__version__ = '0.18.0+cpu'
git_version = 'a897aa927f94909ac3e644ea7ab015f97c2f66d0'
