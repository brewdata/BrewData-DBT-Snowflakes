"""dcor package tests"""
