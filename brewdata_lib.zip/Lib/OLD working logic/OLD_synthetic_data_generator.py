from strategy import Strategies
from pattern import Pattern
# from multiprocessing.sharedctypes import Value
import pandas as pd
# from realtabformer import REaLTabFormer
# import sqlalchemy as sq
import json
# import datetime
# import string
import random
# import db_operations as sdb
# from deepod.models.tabular import DeepSVDD, DevNet
from sdv.single_table.utils import detect_discrete_columns
# from sklearn.model_selection import train_test_split
from ctgan.data_transformer import DataTransformer
# import nosql_db_operations as nsdb
import numpy as np
# from bson import ObjectId
# import utils
import faker_service
# from nogan import NoGAN
from sdv.single_table.ctgan import CTGANSynthesizer, TVAESynthesizer
# from sdv.single_table.copulagan import CopulaGANSynthesizer
from sdv.metadata import SingleTableMetadata
import uuid
from utils import handle_nulls_mean, check_not_all_nans, correct_date, MetaData, MetaDataRegistry
# from models import (currentGMTTimestamp, SyntheticDataConnections, SyntheticDataJobSql, SyntheticDataJobExecution, SyntheticDataJobExecutionMonitor,
#                     SyntheticDataColumnConfig, SyntheticDataSubJob, SyntheticDataStrategies, SyntheticDataPattern, SyntheticDataRule, SyntheticDataDroolsFile)
# from time import sleep
# from llama_service import LLAMAService
from strategies import strategy, STRATEGY_MAP
import drools_engine as de
from nested_json_utils import *
# from PII_SE.pii_detection import get_semantic_from_df
# from itertools import chain
from multi_df__utils import *
from io import StringIO

data1 = StringIO(STRATEGY_MAP)
data2 = StringIO(STRATEGY_MAP)
# Read into Pandas DataFrame
id_map = pd.read_csv(data1)
id_map.index = id_map.strategy_name
id_map = id_map['strategy']
stg = Strategies(pd.read_csv(data2))
ptn = Pattern()

oi=0
# oi = LLAMAService()
LOCALES_ATTRIBUTE_MAP = {'en-US': {'person_name': [], 'address': [], 'date': ['days_before', 'days_after',
                                                                              'limit_to_current_date'], 'ssn': [], 'phone_number': []}, 'en-ZA': {'said': [], 'address': []}}

          
def find_zip(l):
    for col in l:
        if col.lower().find('zip') != -1 or col.lower().find('postal') != -1:
            return col
    return -1

def set_db_operation(drivere_name):
    if drivere_name.lower() == 'salesforce':
        return nsdb
    else:
        return sdb

class SyntheticDataGenerator:

    def __init__(self, config=None, locale=None):
        self.faker_obj = None
        self.meta_register = MetaDataRegistry()
        self.dformat = "Format not detected"
        if locale:
            self.faker_obj = faker_service.FakerService(locale)

        if config:
            self.config = config

    def generate_test_data(self, driver_name,engine,configuration):

        df_type = None
        column_strategy = ""
        constraints = ""
        dependent_fields = ""
        columnlets_pattern = ""
        data = []
        return_status = "Success"
        select_query=""
        before=pd.DataFrame()
        df=pd.DataFrame()
        dpstr = "[{"
        
        db = set_db_operation(driver_name)
        source_engine = engine
        source_schema = configuration['source_schema']
        source_table = configuration['source_table']
        self.faker_obj = faker_service.FakerService(configuration['locale'])
        if driver_name == 'salesforce':
            pk_columns = db.get_primarykeys(source_engine, source_table)
        else:
            pk_columns = db.get_primarykeys(
                source_engine, source_schema, source_table)

        col_data = configuration['columns_config']
        table_data = configuration['table_data']
        # getting table rows count
        if driver_name == 'salesforce':
            table_rows_count = db.get_table_rows_count(
                source_engine, source_table)
        else:
            table_rows_count = db.get_table_rows_count(
                source_engine, source_schema, source_table)
        # getting table columns
        if driver_name == 'salesforce':
            columns_list = db.get_columns_names(source_engine, source_table)
        else:
            columns_list = db.get_columns_names(
                source_engine, source_schema, source_table)
        columns = ",".join(columns_list)
        # isview = db.is_view(source_engine, source_schema, source_table)
        ############ without rules ##############
        if not table_data:
            if driver_name == 'mssql':
                columns = db.mssql_column_list(columns_list)
                select_query = f'select top 1  {columns}  from {source_schema}.{source_table} order by 1'
            elif driver_name == 'mysql' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit 1'
            elif driver_name == 'oracle':
                select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= 1 order by 1'
            elif driver_name == 'salesforce':
                select_query = f'select  {columns}  from {source_table} limit 1'
            before = db.get_sql_to_df(source_engine, select_query)
            df = before.copy()
            if df.empty:
                df = db.fill_empty_df(df,columns_list)
            col_id = 0
            on_update_cascade = 0
            all_deps = []
            all_dep_cols=[]

            for cd in col_data:
                col_id = col_id + 1
                tokenization_type = 'NA'
                delimiter_value = None
                columnlets_pattern = None
                source_column = cd['source_column']
                destination_column = cd['source_column']
                patterns = cd['pattern']
                strategy_id = cd['strategy_id']
                dependent_fields = cd['dependent_fields']
                df_type = "str" if isinstance(dependent_fields, str) else "list" ##type(dependent_fields).__name__
                
                # child and parent relation
                actual_table = source_table
                if driver_name != 'salesforce':
                    column_relations_df = db.get_column_relations(
                        source_engine, source_schema, source_table, source_column, 'parent', driver_name)
                    column_relations = column_relations_df.to_json(
                        orient='records')
                    relations = json.loads(column_relations)
                    update_rule = self.find_onupdate_cascade(
                        source_engine, source_schema, source_table, source_table, source_column, driver_name, db)
                    if relations:
                        update_rule = self.find_onupdate_cascade(
                            source_engine, source_schema, source_table, relations[0]['table_name'], relations[0]['column_name'], driver_name, db)
                        if update_rule == 1:
                            source_schema = relations[0]['schema_name']
                            source_table = relations[0]['table_name']
                            source_column = relations[0]['column_name']
                            destination_column = source_column
                            columns_list = db.get_columns_names(
                                source_engine, source_schema, source_table)
                            columns = ",".join(columns_list)
                            if driver_name == 'mssql':
                                columns = db.mssql_column_list(columns_list)
                                select_query = f'select top 1  {columns}  from {source_schema}.{source_table} order by 1'
                            elif driver_name == 'mysql' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                                select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit 1'
                            elif driver_name == 'oracle':
                                select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= 1 order by 1'
                            df = db.get_sql_to_df(source_engine, select_query)
                            return_status = f"Not possible to change the other columns when changed to the Primary/FK Key {source_column} values"
                            on_update_cascade = 0
                            if len(col_data) > 1 and actual_table != source_table:
                                on_update_cascade = 1
                        elif update_rule == 0 and relations[0]['table_name'] != source_table and int(table_rows_count) > int(table_rows_count)-1:
                            return_status = f'ON CASCADE on tables are not turned on. {source_column} is not updatable. Please contact DB Admin for support.'
                            on_update_cascade = 1
                    if len(pk_columns) != 0 and update_rule == 0 and source_column == pk_columns[0] and int(table_rows_count) > int(table_rows_count)-1:
                        return_status = f'ON CASCADE on tables are not turned on. {source_column} is not updatable. Please contact DB Admin for support.'
                        on_update_cascade = 1
                    if on_update_cascade == 1:
                        return return_status
                if strategy_id:
                    column_strategy = stg.get_strategies_id_by_id(strategy_id)
                    constraints = stg.get_constraints_by_id(strategy_id)

                    df, all_dep, mod_cols = self.generate_syn_data_new(
                        source_column, destination_column, tokenization_type, df, strategy_id, "", dependent_fields)
                    all_deps.append(all_dep)
                    all_dep_cols.append(mod_cols)
                else:
                    # with session_scope() as db_session1:
                    tokenization_type = patterns['tokenization_type']
                    delimiter_value = patterns['delimiter_value']
                    columnlets_pattern = patterns['columnlets_pattern']
                    df[f'{source_column}_source_col'] = df[f'{source_column}']
                    plist = 0
                    for col_pattern in columnlets_pattern:
                        if col_pattern:
                            strategy_id = col_pattern['strategy_id']
                            dependent_fields = col_pattern['dependent_fields']
                            column_strategy = stg.get_strategies_id_by_id(strategy_id)
                            constraints = stg.get_constraints_by_id(strategy_id)
                            if not column_strategy:
                                raise Exception(f"unable to find strategy")
                            source_dep_col = []
                            destin_dep_col = []
                            desti_col = []
                            df_type = "str" if isinstance(dependent_fields, str) else "list"  ###type(dependent_fields).__name__
                            if dependent_fields != 'None' and dependent_fields:
                                dpstr = "[{"
                                if df_type == 'str':
                                    dpjson = json.loads(dependent_fields)
                                    for dp_cols in dpjson:
                                        for col in dp_cols:
                                            if col == 'column_name':
                                                source_dep_col.append(
                                                    f"{dp_cols[col]}_source_col")
                                                destin_dep_col.append(
                                                    f"{dp_cols[col]}_destination_col")
                                                df[f"{dp_cols[col]}_source_col"] = df[dp_cols[col]]
                                elif df_type == 'list':
                                    for dp_cols in dependent_fields:
                                        for col in dp_cols:
                                            dpstr = dpstr + '"'+col + \
                                                '":"'+dp_cols[col]+'",'
                                            if col == 'column_name':
                                                source_dep_col.append(
                                                    f"{dp_cols[col]}_source_col")
                                                destin_dep_col.append(
                                                    f"{dp_cols[col]}_destination_col")
                                                df[f"{dp_cols[col]}_source_col"] = df[dp_cols[col]]
                                    dpstr = dpstr[0:len(dpstr)-1] + "}]"
                                else:
                                    dpstr = '""'
                                for dep_col in destin_dep_col:
                                    df[dep_col] = ""
                                    desti_col.append(dep_col)
                            desti_col.insert(
                                0, f'{destination_column}_destination_col')
                            if plist == 0:
                                df[f'{destination_column}_destination_col'] = ""
                                return_values = []
                            if plist == 0:
                                for data_value in df[f'{source_column}']:
                                    syn_value = data_value
                                    if tokenization_type == 'fixed':
                                        return_values.append(self.columnlet_split_fixed(str(
                                            syn_value), column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                                    elif tokenization_type == 'variable':
                                        return_values.append(self.columnlet_split_variable(str(
                                            syn_value), delimiter_value, column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                            if plist != 0:
                                for data_value in df[f'{destination_column}_destination_col']:
                                    syn_value = data_value
                                    if tokenization_type == 'fixed':
                                        return_values.append(self.columnlet_split_fixed(str(
                                            syn_value), column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                                    elif tokenization_type == 'variable':
                                        return_values.append(self.columnlet_split_variable(str(
                                            syn_value), delimiter_value, column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                            plist = plist+1
                            ind = 0
                            for rvalues in return_values:
                                for cols in rvalues:
                                    for col in cols:
                                        if col in desti_col:
                                            df[col][ind] = cols[col]
                df = self.calculate_dependent_fields(df, all_deps)

        else:  # drools test ###################
            rule_id = table_data['rule_id']
            input_fields = table_data['input_fields']
            # with session_scope() as db_session:
            # rule = db_session.query(SyntheticDataRule).filter(
            #     SyntheticDataRule.id == rule_id).first()
            # if rule:
            url = "rule.url"

            if driver_name == 'mssql':
                columns = db.mssql_column_list(columns_list)
                select_query = f'select top 1  {columns}  from {source_schema}.{source_table} order by 1'
            elif driver_name == 'mysql' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit 1'
            elif driver_name == 'oracle':
                select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= 1 order by 1'
            elif driver_name == 'salesforce':
                select_query = f'select  {columns}  from {source_table} limit 1'
            df = db.get_sql_to_df(source_engine, select_query)
            if df.empty:
                df=db.fill_empty_df(df,columns_list,0)
            ########### Calling rules ################
            resulfdf = self.generate_drolls_data(df, input_fields, url)
            resultjson = resulfdf.to_json(orient='records')
            data = json.loads(resultjson.replace("\\n", ""))
        src_column = [col.replace('_source_col','') for col in df.columns if 'source_col' in col]
        desti_column = [col for col in df.columns if 'destination_col' in col]
                
        df[src_column]=df[desti_column]
        after=df[columns_list]

        return before,after

    def synthetic_table_test_data(self,  driver_name,engine, configuration):

        df_type = None
        column_strategy = ""
        name_strategy = ""
        constraints = ""
        dependent_fields = ""
        columnlets_pattern = ""
        data = []
        before=pd.DataFrame()
        model = ""
        dpstr = "[{"
        db = set_db_operation(driver_name)
        source_engine=engine
        source_database = configuration['database']
        source_schema = configuration['source_schema']
        source_table = configuration['source_table']
        self.faker_obj = faker_service.FakerService(configuration['locale'])
        if driver_name == 'salesforce':
            pk_columns = db.get_primarykeys(source_engine, source_table)
        else:
            pk_columns = db.get_primarykeys(
                source_engine, source_schema, source_table)
        col_data = configuration['columns_config']
        # getting table rows count
        if driver_name == 'salesforce':
            table_rows_count = db.get_table_rows_count(
                source_engine, source_table)
        else:
            table_rows_count = db.get_table_rows_count(
                source_engine, source_schema, source_table)
        # getting table columns
        if driver_name == 'salesforce':
            columns_list = db.get_columns_names(source_engine, source_table)
        else:
            columns_list = db.get_columns_names(
                source_engine, source_schema, source_table)
        columns = ",".join(columns_list)
        testrows = int(configuration['row_limit'])  # CHANGE
        if int(table_rows_count) < 10:
            testrows = int(table_rows_count)
        else:
            testrows = 10
        table_data = configuration['table_data']
        if not table_data:
            if driver_name == 'mssql':
                columns = db.mssql_column_list(columns_list)
                select_query = f'select top {testrows}  {columns}  from {source_schema}.{source_table} order by 1'
            elif driver_name == 'mysql' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit {testrows}'
            elif driver_name == 'oracle':
                select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= {testrows} order by 1'
            elif driver_name == 'salesforce':
                select_query = f'select  {columns}  from {source_table} limit {testrows}'
            before = db.get_sql_to_df(source_engine, select_query)
            df=before.copy()
            if df.empty:
                df=db.fill_empty_df(df,columns_list,10)
            col_id = 0
            on_update_cascade = 0
            return_status = "Success"
            actual_table = source_table
            nn_columns = []
            nn_dest_columns = []
            nn_discrete_columns = []
            flags_nn = [False, False, False, False, False]
            nn_columns = {'selected': [], 'non_selected': []}
            all_deps = []
            all_dep_cols = []
            for cd in col_data:
                col_id = col_id + 1
                tokenization_type = 'NA'
                delimiter_value = None
                columnlets_pattern = None
                source_column = cd['source_column']
                destination_column = cd['source_column']
                patterns = cd['pattern']  # CHANGE
                strategy_id = cd['strategy_id']
                dependent_fields = cd['dependent_fields']
                df_type = "str" if isinstance(dependent_fields, str) else "list" ##type(dependent_fields).__name__
                
                if driver_name != 'salesforce':
                    column_relations_df = db.get_column_relations(
                        source_engine, source_schema, source_table, source_column, 'parent', driver_name)
                    column_relations = column_relations_df.to_json(
                        orient='records')
                    relations = json.loads(column_relations)
                    update_rule = self.find_onupdate_cascade(
                        source_engine, source_schema, source_table, source_table, source_column, driver_name, db)
                    if relations:
                        update_rule = self.find_onupdate_cascade(
                            source_engine, source_schema, source_table, relations[0]['table_name'], relations[0]['column_name'], driver_name, db)
                        if update_rule == 1:
                            source_schema = relations[0]['schema_name']
                            source_table = relations[0]['table_name']
                            source_column = relations[0]['column_name']
                            destination_column = source_column
                            columns_list = db.get_columns_names(
                                source_engine, source_schema, source_table)
                            columns = ",".join(columns_list)
                            
                            if driver_name == 'mssql':
                                columns = db.mssql_column_list(columns_list)
                                select_query = f'select top {testrows}  {columns}  from {source_schema}.{source_table} order by 1'
                            elif driver_name == 'mysql' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                                select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit {testrows}'
                            elif driver_name == 'oracle':
                                select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= {testrows} order by 1'
                            df = db.get_sql_to_df(source_engine, select_query)
                            return_status = f"Not possible to change the other columns when chaninged to the Primary/FK Key {source_column} values"
                            on_update_cascade = 0
                            if len(col_data) > 1 and actual_table != source_table:
                                on_update_cascade = 1
                        elif update_rule == 0 and relations[0]['table_name'] != source_table and int(table_rows_count) > int(table_rows_count)-1:
                            return_status = f'ON CASCADE on tables are not turned on. {source_column} is not updatable. Please contact DB Admin for support.'
                            on_update_cascade = 1
                    if len(pk_columns) != 0 and update_rule == 0 and source_column == pk_columns[0] and int(table_rows_count) > int(table_rows_count)-1:
                        return_status = f'ON CASCADE on tables are not turned on. {source_column} is not updatable. Please contact DB Admin for support.'
                        on_update_cascade = 1
                    if on_update_cascade == 1:
                        return return_status
                if strategy_id:
                    column_strategy = stg.get_strategies_id_by_id(strategy_id)
                    name_strategy = stg.get_strategies_name_by_id(strategy_id)
                    constraints = stg.get_constraints_by_id(strategy_id)
                    typ = stg.get_strategies_type_by_id(strategy_id)
                    if name_strategy.__contains__('CTGAN'):
                        flags_nn[0] = True
                        model = 'CTGAN'
                        nn_columns['selected'].append(source_column)
                        nn_dest_columns.append(destination_column)
                        if typ == 'categorical':
                            nn_discrete_columns.append(source_column)
                        continue
                    if name_strategy.__contains__('CopulaGAN'):
                        flags_nn[1] = True
                        model = 'CopulaGAN'
                        nn_columns['selected'].append(source_column)
                        nn_dest_columns.append(destination_column)
                        if typ == 'categorical':
                            nn_discrete_columns.append(source_column)
                        continue
                    if name_strategy.__contains__('TVAE'):
                        flags_nn[2] = True
                        model = 'TVAE'
                        nn_columns['selected'].append(source_column)
                        nn_dest_columns.append(destination_column)
                        if typ == 'categorical':
                            nn_discrete_columns.append(source_column)
                        continue
                    if name_strategy.__contains__('Transformer'):
                        flags_nn[3] = True
                        model = 'Transformer'
                        nn_columns['selected'].append(source_column)
                        nn_dest_columns.append(destination_column)
                        if typ == 'categorical':
                            nn_discrete_columns.append(source_column)
                        continue
                    if name_strategy.__contains__('NoGAN'):
                        flags_nn[4] = True
                        model = 'NoGAN'
                        nn_columns['selected'].append(source_column)
                        nn_dest_columns.append(destination_column)
                        if typ == 'categorical':
                            nn_discrete_columns.append(source_column)
                        continue
                    df, all_map, mod_cols = self.generate_syn_data_new(
                        source_column, destination_column, tokenization_type, df, strategy_id, "", dependent_fields)
                    all_deps.append(all_map)
                    all_dep_cols.append(mod_cols)
                else:
                    # with session_scope() as db_session1:
                    tokenization_type = patterns['tokenization_type']
                    delimiter_value = patterns['delimiter_value']
                    columnlets_pattern = patterns['columnlets_pattern']
                    df[f'{source_column}_source_col'] = df[f'{source_column}']
                    plist = 0
                    for col_pattern in columnlets_pattern:
                        if col_pattern:
                            strategy_id = col_pattern['strategy_id']

                            dependent_fields = col_pattern['dependent_fields']
                            column_strategy = stg.get_strategies_id_by_id(strategy_id)
                            constraints = stg.get_constraints_by_id(strategy_id)

                            if not column_strategy:
                                raise Exception(f"unable to find strategy")
                            source_dep_col = []
                            destin_dep_col = []
                            desti_col = []
                            df_type = "str" if isinstance(dependent_fields, str) else "list" ##type(dependent_fields).__name__
                            if dependent_fields != 'None' and dependent_fields:
                                dpstr = "[{"
                                if df_type == 'str':
                                    dpjson = json.loads(dependent_fields)
                                    for dp_cols in dpjson:
                                        for col in dp_cols:
                                            if col == 'column_name':
                                                source_dep_col.append(
                                                    f"{dp_cols[col]}_source_col")
                                                destin_dep_col.append(
                                                    f"{dp_cols[col]}_destination_col")
                                                df[f"{dp_cols[col]}_source_col"] = df[dp_cols[col]]
                                elif df_type == 'list':
                                    for dp_cols in dependent_fields:
                                        for col in dp_cols:
                                            dpstr = dpstr + '"'+col + \
                                                '":"'+dp_cols[col]+'",'
                                            if col == 'column_name':
                                                source_dep_col.append(
                                                    f"{dp_cols[col]}_source_col")
                                                destin_dep_col.append(
                                                    f"{dp_cols[col]}_destination_col")
                                                df[f"{dp_cols[col]}_source_col"] = df[dp_cols[col]]
                                    dpstr = dpstr[0:len(dpstr)-1] + "}]"
                                else:
                                    dpstr = '""'
                                for dep_col in destin_dep_col:
                                    df[dep_col] = ""
                                    desti_col.append(dep_col)
                            desti_col.insert(
                                0, f'{destination_column}_destination_col')
                            return_values = []
                            if plist == 0:
                                df[f'{destination_column}_destination_col'] = ""

                            if plist == 0:
                                for data_value in df[f'{source_column}']:
                                    syn_value = data_value
                                    if tokenization_type == 'fixed':
                                        return_values.append(self.columnlet_split_fixed(str(
                                            syn_value), column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                                    elif tokenization_type == 'variable':
                                        return_values.append(self.columnlet_split_variable(str(
                                            syn_value), delimiter_value, column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                            if plist != 0:
                                for data_value in df[f'{destination_column}_destination_col']:
                                    syn_value = data_value
                                    if tokenization_type == 'fixed':
                                        return_values.append(self.columnlet_split_fixed(str(
                                            syn_value), column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                                    elif tokenization_type == 'variable':
                                        return_values.append(self.columnlet_split_variable(str(
                                            syn_value), delimiter_value, column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                            plist = plist+1
                            ind = -1
                            for rvalues in return_values:
                                ind = ind+1
                                for cols in rvalues:
                                    for col in cols:
                                        if col in desti_col:
                                            df[col][ind] = cols[col]

                depcol = []
                df_type = "str" if isinstance(dependent_fields, str) else "list"
                
            if model:
                self.generate_fake_table_nn(df, nn_columns, nn_discrete_columns, testrows, nn_dest_columns)

            df = self.calculate_dependent_fields(df, all_deps)
            
            if source_column.lower().find('date') != -1:
                df[f'{source_column}'] = df[f'{source_column}'].astype(str)
                df[f'{source_column}_source_col'] = df[f'{source_column}_source_col'].astype(
                    str)
                df[f'{source_column}_destination_col'] = df[f'{source_column}_destination_col'].astype(
                    str)

            source_column = [col for col in df.columns if 'source_col' in col]
            dest_column =[col for col in df.columns if 'destination_col' in col]
            columns_array = [x.replace("_source_col", "")
                             for x in source_column]

            df[columns_array]=df[dest_column]
            after=df[columns_list]
            
        return before,after
            

    def generate_data_from_job(self, driver_name,engine,config):

        return_status = 'success'
        update_rule = ""
        dataframes = pd.DataFrame()
        fdf = pd.DataFrame()
        newdf = pd.DataFrame()
        mdf = pd.DataFrame()
        df_nn = pd.DataFrame()
        on_update_cascade = 0
        num_samples = None
        syn_table_name = ""
        sc = dc = ""
        before=None
        after=None
        locale=None
        try:
            db = set_db_operation(driver_name)
            
            source_database = config['database']
            destination_database = config['database'] #config['destination_database']
            source_engine=engine
            destination_engine=engine
            source_schema = config['source_schema']
            destination_schema = config['source_schema'] #config['destination_schema']
            source_table = config['source_table']
            destination_table = config['source_table'] #config['destination_table']
            row_limit = config['row_limit']
            table_data = config['table_data']
            bias = config['bias']
            locale = config['locale']
            # getting table rows count
            if driver_name == 'salesforce':
                table_rows_count = db.get_table_rows_count(
                    source_engine, source_table)
            else:
                table_rows_count = db.get_table_rows_count(
                    source_engine, source_schema, source_table)
            if not row_limit:
                row_limit = int(table_rows_count)
            # getting table columns
            if driver_name == 'salesforce':
                columns_list = db.get_columns_names(
                    source_engine, source_table)
            else:
                columns_list = db.get_columns_names(
                    source_engine, source_schema, source_table)
            columns = ",".join(columns_list)

            if not table_data:
                
                self.faker_obj = faker_service.FakerService(locale)
                if driver_name == 'salesforce':
                    pk_columns = db.get_primarykeys(
                        source_engine, source_table)
                else:
                    pk_columns = db.get_primarykeys(
                        source_engine, source_schema, source_table)
                actual_table = source_table
                # validating ON DELETE CASCADE and row limit
                on_update_cascade = 0

                columns_config=config['columns_config']
                for cc in columns_config:
                    source_column = cc['source_column']
                    destination_column = cc['source_column']
                    # child and parent relation
                    if driver_name != 'salesforce':
                        column_relations_df = db.get_column_relations(
                            source_engine, source_schema, source_table, source_column, 'parent', driver_name)
                        column_relations = column_relations_df.to_json(
                            orient='records')
                        relations = json.loads(column_relations)
                        update_rule = self.find_onupdate_cascade(
                            source_engine, source_schema, source_table, source_table, source_column, driver_name, db)
                        if relations:
                            update_rule = self.find_onupdate_cascade(
                                source_engine, source_schema, source_table, relations[0]['table_name'], relations[0]['column_name'], driver_name, db)
                            if update_rule == 1:
                                source_schema = relations[0]['schema_name']
                                source_table = relations[0]['table_name']
                                source_column = relations[0]['column_name']
                                destination_column = source_column
                                destination_table = source_table
                                destination_schema = source_schema
                                columns_list = db.get_columns_names(
                                    source_engine, source_schema, source_table)
                                columns = ",".join(columns_list)

                                return_status = f"Sorry this job is aborted, Not possible to change the other columns when chaninged to the Primary/FK Key {source_column} values"
                                on_update_cascade = 0
                                if len(columns_config) > 1 and actual_table != source_table:
                                    on_update_cascade = 1
                            elif update_rule == 0 and relations[0]['table_name'] != source_table:
                                return_status = f'Sorry this job is aborted, ON CASCADE on tables are not turned on. {source_column} is not updatable, it is Primary/FK Key. Please contact DB Admin for support.'
                                on_update_cascade = 1

                        if len(pk_columns) != 0 and update_rule == 0 and source_column == pk_columns[0]:
                            return_status = f'Sorry this job is aborted, ON CASCADE on tables are not turned on. {source_column} is not updatable, it is Primary/FK Key. Please contact DB Admin for support.'
                            on_update_cascade = 1
                # fetching table column data
                if driver_name == 'mssql':
                    columns = db.mssql_column_list(columns_list)
                    select_query = f'select {columns}  from {source_schema}.{source_table} order by 1'
                elif driver_name == 'mysql' or driver_name == 'oracle' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                    select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1'
                elif driver_name == 'salesforce':
                    select_query = f'select {columns} from {source_table}'
                idf = db.get_sql_to_df(source_engine, select_query)
                if idf.empty:
                    idf=db.fill_empty_df(idf,columns_list)
                    
                column_types = idf.dtypes
                # table original values action is assign to initial(I)
                idf['action'] = "I"
                dataframes = idf
                if on_update_cascade == 0:
                    if int(table_rows_count) > 1 and on_update_cascade == 0:
                        # df=idf
                        if int(table_rows_count) > row_limit:
                            if driver_name == 'mssql':
                                columns = db.mssql_column_list(
                                    columns_list)
                                select_query = f'select top {row_limit}  {columns}  from {source_schema}.{source_table} order by 1'
                            elif driver_name == 'mysql' or driver_name == 'ibmdb2':
                                select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit {row_limit}'
                            elif driver_name == 'oracle':
                                select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= {row_limit} order by 1'
                            elif driver_name == 'salesforce':
                                select_query = f'select  {columns}  from {source_table} order by {columns_list[0]} limit {row_limit}'

                        # getting data modiftion by limited rows
                        number_samples = row_limit
                        mdf, df_nn = self.generation_columns_synthatic_data(
                            source_engine, columns_config, source_schema, source_table, driver_name, select_query, number_samples, db, columns_list, bias=bias)

                        new_cols = None
                        new_cols = [
                            col for col in mdf.columns if 'destination_col' in col or 'source_col' in col]
                        source_column = [
                            col for col in mdf.columns if 'source_col' in col]
                        destination_column = [
                            col for col in mdf.columns if 'destination_col' in col]
                        
                        idf[list(new_cols)] = np.nan
                        dataframes = [idf, mdf]
                        if driver_name == 'salesforce':

                            for field in columns_list:
                                metadata = db.get_column_metadata(
                                    source_engine, source_table, field)
                                try:
                                    if metadata['type'] == 'Date':
                                        mdf[f'{field}'] = pd.to_datetime(
                                            mdf[f'{field}'])
                                        mdf[f'{field}'] = mdf[f'{field}'].dt.strftime(
                                            '%Y-%m-%d')
                                    elif metadata['type'].find('Date') != -1:
                                        mdf[f'{field}'] = pd.to_datetime(
                                            mdf[f'{field}'])
                                        mdf[f'{field}'] = mdf[f'{field}'].dt.strftime(
                                            '%Y-%m-%dT%H:%M:%S.0000Z')
                                except:
                                    pass
                            # db.update_to_sql_from_df_column(
                            #     mdf, destination_engine, destination_table, source_column, destination_column, driver_name)
                        else:
                            for field in destination_column:
                                if field.lower().find('date') != -1:
                                    mdf[f'{field}'] = pd.to_datetime(
                                        mdf[f'{field}'])
                        # updating synthatic data
                            # db.update_to_sql_from_df_one_column(
                            #     mdf, destination_engine, destination_database, destination_table, destination_schema, source_column, destination_column, driver_name)
                        # new synthatic data into table
                    if int(table_rows_count) < int(row_limit):
                        identity_key_next_value = None
                        # checking table have identity key column
                        if driver_name == 'mssql':
                            identity_sql_query = f"SELECT NAME AS COLUMNNAME FROM SYS.IDENTITY_COLUMNS WHERE OBJECT_NAME(OBJECT_ID) = '{destination_table}' AND OBJECT_SCHEMA_NAME(object_id) = '{destination_schema}'"
                            identity_column = db.get_sql_to_df(
                                destination_engine, identity_sql_query)
                            if driver_name == 'mssql' and not identity_column.empty:
                                db.execute_empty_result_query(
                                    destination_engine, f'SET IDENTITY_INSERT {destination_schema}.{destination_table} ON')
                                identity_key_next_value = int(float(db.next_identity_value(
                                    destination_engine, destination_schema, destination_table, driver_name)))
                            # generating table new rows and inserting into table
                        if driver_name == 'salesforce':
                            columns_list = db.get_columns_names(
                                source_engine, source_table, 'insert')
                        if not df_nn.empty:
                            positions = {}
                            columns_list_aux = columns_list.copy()
                            for i, col in enumerate(columns_list):
                                if df_nn.columns.__contains__(col):
                                    columns_list_aux.remove(col)
                                    positions[col] = i
                            columns_list = columns_list_aux
                        column_metas = {}
                        for column in columns_list:
                            if driver_name == 'salesforce':
                                column_meta = db.get_column_metadata(
                                destination_engine, source_table, column)
                            else:
                                column_meta = db.get_column_metadata(
                                destination_engine, source_schema, source_table, column)
                            column_metas[column] = column_meta

                        keycolumns = None
                        if driver_name.lower() == 'mssql':
                            keycolumns_list = db.get_fk_pk_key_columns_mssql(
                                destination_engine, source_schema, source_table)
                        elif driver_name.lower() == 'mysql':
                            keycolumns_list = db.get_fk_pk_key_columns_mysql(
                                destination_engine, source_schema, source_table)
                        elif driver_name.lower() == 'oracle':
                            keycolumns_list = db.get_fk_pk_key_columns_oracle(
                                destination_engine, source_schema, source_table)
                        elif driver_name.lower() == 'ibmdb2':
                            keycolumns_list = db.get_fk_pk_key_columns_ibmdb2(
                                destination_engine, source_schema, source_table)
                        elif driver_name.lower() == 'postgresql':
                            keycolumns_list = db.get_fk_pk_key_columns_postgres(
                                destination_engine, source_schema, source_table)
                        elif driver_name.lower() == 'salesforce':
                            keycolumns_list = db.get_fk_pk_key_columns(
                                destination_engine, source_table)
                        keycolumns_list_df = keycolumns_list.to_json(
                            orient='records')
                        if keycolumns_list_df:
                            keycolumns = json.loads(keycolumns_list_df)
                        if len(pk_columns) >= 1:
                            if driver_name == 'salesforce':
                                newdf = self.generate_new_data(pd.DataFrame(), destination_engine, destination_database, source_schema, source_table, keycolumns, columns_list, row_limit - int(
                                    table_rows_count), identity_key_next_value, driver_name, column_metas, column_types, db, mdf, columns_config, False, faker=locale, nn_df=df_nn)
                            else:
                                newdf = self.generate_new_data(mdf[pk_columns[0]], destination_engine, destination_database, source_schema, source_table, keycolumns, columns_list, row_limit - int(
                                    table_rows_count), identity_key_next_value, driver_name, column_metas, column_types, db, mdf, columns_config, False, faker=locale, nn_df=df_nn)
                        else:
                            if driver_name == 'salesforce':
                                newdf = self.generate_new_data(pd.DataFrame(), destination_engine, destination_database, source_schema, source_table, keycolumns, columns_list, row_limit - int(
                                    table_rows_count), identity_key_next_value, driver_name, column_metas, column_types, db, mdf, columns_config, False, faker=locale, nn_df=df_nn)
                            else:
                                newdf = self.generate_new_data(pd.DataFrame(), destination_engine, destination_database, source_schema, source_table, keycolumns,columns_list, row_limit - int(
                                    table_rows_count), identity_key_next_value, driver_name, column_metas, column_types, db, mdf, columns_config, False, faker=locale, nn_df=df_nn)
                        if not df_nn.empty:
                            for col in positions:
                                x = df_nn[col].values.tolist()
                                newdf.insert(positions[col], col, x)
                        if len(newdf) != 0:
                            if driver_name == 'salesforce':
                                for field in columns_list:
                                    metadata = db.get_column_metadata(
                                        source_engine, source_table, field)
                                    try:
                                        if metadata['type'] == 'Date':
                                            newdf[f'{field}'] = pd.to_datetime(
                                                newdf[f'{field}'])
                                            newdf[f'{field}'] = newdf[f'{field}'].dt.strftime(
                                                '%Y-%m-%d')
                                        elif metadata['type'].find('Date') != -1:
                                            newdf[f'{field}'] = pd.to_datetime(
                                                newdf[f'{field}'])
                                            newdf[f'{field}'] = newdf[f'{field}'].dt.strftime(
                                                '%Y-%m-%dT%H:%M:%S.0000Z')
                                    except:
                                        pass
                                # db.insert_to_sql_from_df_column(
                                #     newdf, destination_engine, destination_table, driver_name)
                            else:
                                col_list = list(newdf.columns.values)
                                for field in col_list:
                                    if field.lower().find('date') != -1:
                                        newdf[field] = pd.to_datetime(
                                            newdf[field])
                                # newdf.to_sql(destination_table, destination_engine,
                                #              if_exists='append', index=False, schema=destination_schema)
                            newdf['action'] = 'N'
                        if driver_name == 'mssql' and not identity_column.empty:
                            db.execute_empty_result_query(
                                destination_engine, f'SET IDENTITY_INSERT {destination_schema}.{destination_table} OFF')

                        if int(table_rows_count) > 1 and on_update_cascade == 0 and len(newdf) != 0:
                            newdf[list(new_cols)] = np.nan
                        if len(dataframes) > 1 and mdf.shape[0] != 0 and len(newdf) != 0:
                            dataframes.append(newdf)
                        elif len(newdf) != 0:
                            dataframes = pd.concat([dataframes, newdf])
                    if len(dataframes) > 1 and mdf.shape[0] != 0:
                        fdf = pd.concat(dataframes)
                    else:
                        fdf = dataframes
            else:  # Drools Operation ################
                table_data1 = json.loads(table_data)
                rule_id = table_data1['rule_id']
                input_fields = table_data1['input_fields']

                if len(input_fields):
                    # rule = db_session.query(SyntheticDataRule).filter(
                    #     SyntheticDataRule.id == rule_id).first()
                    url = url #rule.url
                else:
                    # rule = db_session.query(SyntheticDataDroolsFile).filter(SyntheticDataDroolsFile.id == rule_id).first()
                    url=None

                if driver_name == 'mssql':
                    columns = db.mssql_column_list(
                        columns_list)
                    select_query = f'select top {row_limit}  {columns}  from {source_schema}.{source_table} order by 1'
                elif driver_name == 'mysql' or driver_name == 'ibmdb2':
                    select_query = f'select  {columns}  from {source_schema}.{source_table} order by 1 limit {row_limit}'
                elif driver_name == 'oracle':
                    select_query = f'select  {columns}  from {source_schema}.{source_table} WHERE ROWNUM <= {row_limit} order by 1'
                elif driver_name == 'salesforce':
                    select_query = f'select  {columns}  from {source_table} order by {columns_list[0]} limit {row_limit}'
                df = db.get_sql_to_df(source_engine, select_query)
                if df.empty:
                    df = db.fill_empty_df(df,columns_list,0)
                ########### Calling rules ################
                if url:
                    finaldf = self.generate_drolls_data(df, input_fields, url)
                else:
                    ruleName = "rule_name" #rule.ruleName
                    finaldf = self.generate_custom_drools(df, ruleName, source_table if source_table else "File")
                dt_columns_list = db.get_columns_names(
                    source_engine, destination_schema, destination_table)
                # del dt_columns_list[0]
                # finaldf.columns = dt_columns_list
                dtyp = None
                finaldf.to_sql(destination_table, destination_engine, if_exists='replace',
                                index=False, schema=destination_schema, dtype=dtyp)
                fdf = pd.concat([df, finaldf], axis=1)
                source_column = ""
                destination_column = ""

            before = fdf[fdf['action']=='I']
            mdf = fdf[fdf['action']=='M'].copy()
            before=before[columns_list]
            src_column = [col.replace('_source_col','') for col in fdf.columns if 'source_col' in col]
            desti_column = [col for col in fdf.columns if 'destination_col' in col]
            mdf[src_column] = mdf[desti_column]
            mdf=mdf[columns_list]
            if len(newdf) != 0:
                newdf=newdf[columns_list]
                dataframes=[mdf,newdf]
            dataframes=[mdf]
            after=pd.concat(dataframes)
            after=after.reset_index()
        except Exception as e:
            return_status = 'failed'
           
        return before, after
    
    def calculate_dependent_fields(self, df, all_deps):
        try:
            dummy_df = ""
            for post_dependencies in all_deps:
                if post_dependencies:
                    dummy_df = pd.DataFrame()
                    modified_cols = []
                    for col in df.columns:
                        if 'destination_' in col:
                            col = col.replace("_destination_col", "")
                            dummy_df[col] = df[f"{col}_destination_col"]
                            modified_cols.append(col)
                        elif "source_" not in col:
                            dummy_df[col] = df[col]

                    dummy_df.attrs['connection_map'] = post_dependencies

                    modified_cols_new = []
                    for col in modified_cols:
                        if col in post_dependencies:
                            modified_cols_new.extend([c if isinstance(c, str) else c[0] for c in post_dependencies[col]])

                    for col in modified_cols_new:  # for creating source and destination column for dependet column P1
                        dummy_df[f"{col}_source_col"] = df[col]
                    # modified_cols.extend(modified_cols_new)
                    for col in modified_cols:
                        dummy_df = update_column_data(dummy_df, col, df[f"{col}_destination_col"].to_list(), block_list='fresh')
                        dummy_df[f"{col}_destination_col"] = dummy_df[col]
                        dummy_df[f"{col}_source_col"] = df[col]
                        # dummy_df[col] = df[col]

                    for col in modified_cols_new:  # for creating source and destination column for dependet column P2
                        dummy_df[f"{col}_destination_col"] = dummy_df[col]
            if isinstance(dummy_df,str):
                return df
            return dummy_df
        except Exception as e:
            raise Exception("Problem while calculating dependent field.")

    def calculate_dependent_fields_newdata(self, df, all_deps, mod_cols):
        try: 
            if len(mod_cols)==0:
                return df
            visited = []
            for post_dependencies, mod_col in zip(all_deps, mod_cols):
                if post_dependencies and len(mod_col)!=0:
                    if mod_col[0] not in visited:
                        df = update_column_data(
                            df, mod_col[0], df[f"{mod_col[0]}"].to_list(), block_list='fresh')
                        visited.extend(mod_col)
                    
            return df
        except Exception as e:
            raise Exception("Problem while calculating dependent field for new data.")
        
    def generation_columns_synthatic_data(self, engine, config, source_schema, source_table, driver_name, select_query, num_samples, db,columns_list, is_file=False, df=None, locale=None, is_test=False, bias=None):
        if not is_file:
            df = db.get_sql_to_df(engine, select_query)
            if df.empty:
                df = db.fill_empty_df(df,columns_list,0)
                
            df['action'] = "M"
        hidden_data = df.attrs
        df_nn = pd.DataFrame()
        strategy_id = ""
        dependent_fields = None
        name_strategy = ""
        column_strategy = ""
        model = ""
        
        column_configs = config
        nn_columns = {'selected': [], 'non_selected': []}
        nn_dest_columns = []
        nn_discrete_columns = []
        flags_nn = [False, False, False, False, False]
        changing_columns = []
        all_deps = []
        all_dep_cols=[]
        all_meta = {}
        for cc in column_configs:
            source_column = cc['source_column']
            changing_columns.append(source_column)
            destination_column = cc['source_column']
            pattern_id = cc['pattern_id']
            strategy_id = cc['strategy_id']
            dependent_fields = cc['dependent_fields']
            typ = cc['tokenization_type']
            # child and parent relation
            relations = False
            if not is_file:
                if driver_name != 'salesforce':
                    column_relations_df = db.get_column_relations(
                        engine, source_schema, source_table, source_column, 'parent', driver_name)
                    column_relations = column_relations_df.to_json(
                        orient='records')
                    relations = json.loads(column_relations)
            if strategy_id:
                name_strategy = stg.get_strategies_name_by_id(strategy_id)
            if name_strategy:
                if name_strategy.__contains__('CTGAN'):
                    flags_nn[0] = True
                    model = 'CTGAN'
                    nn_columns['selected'].append(source_column)
                    nn_dest_columns.append(destination_column)
                    if typ == 'categorical':
                        nn_discrete_columns.append(source_column)
                    continue
                if name_strategy.__contains__('CopulaGAN'):
                    flags_nn[1] = True
                    model = 'CopulaGAN'
                    nn_columns['selected'].append(source_column)
                    nn_dest_columns.append(destination_column)
                    if typ == 'categorical':
                        nn_discrete_columns.append(source_column)
                    continue
                if name_strategy.__contains__('TVAE'):
                    flags_nn[2] = True
                    model = 'TVAE'
                    nn_columns['selected'].append(source_column)
                    nn_dest_columns.append(destination_column)
                    if typ == 'categorical':
                        nn_discrete_columns.append(source_column)
                    continue
                if name_strategy.__contains__('Transformer'):
                    flags_nn[3] = True
                    model = 'Transformer'
                    nn_columns['selected'].append(source_column)
                    nn_dest_columns.append(destination_column)
                    if typ == 'categorical':
                        nn_discrete_columns.append(source_column)
                    continue
                if name_strategy.__contains__('NoGAN'):
                    flags_nn[4] = True
                    model = 'NoGAN'
                    nn_columns['selected'].append(source_column)
                    nn_dest_columns.append(destination_column)
                    if typ == 'categorical':
                        nn_discrete_columns.append(source_column)
                    continue
            if relations:
                source_schema = relations[0]['schema_name']
                source_table = relations[0]['table_name']
                source_column = relations[0]['column_name']
            tokenization_type = 'NA'
            pattern = None
            # no patterns
            if strategy_id:
                df, dep_field, mod_cols = self.generate_syn_data_new(
                    source_column, destination_column, tokenization_type, df, strategy_id, pattern, dependent_fields, faker=locale)
            else:  # with patterns
                df, dep_field, mod_cols = self.generate_syn_data_new(
                    source_column, destination_column, tokenization_type, df, strategy_id, pattern_id, dependent_fields, faker=locale)
            all_deps.append(dep_field)
            if mod_cols:
                all_dep_cols.extend(mod_cols)
            else:
                all_dep_cols.extend([])
        
        # for post dependence calculation
        # df = self.calculate_dependent_fields(df, all_deps)
        df.attrs['all_deps'] = all_deps
        df.attrs['all_dep_cols'] = all_dep_cols

        if name_strategy:
            for column in df.columns:
                if not (changing_columns.__contains__(column) or column == 'action' or column.lower().find('_source_col') != -1 or column.lower().find('_destination_col') != -1):
                    column_type = df[column].dtype.kind
                    if check_not_all_nans(df[column]):
                        if ['i', 'u', 'f', 'c'].__contains__(column_type):
                            if not (column.find('phone') != -1 or column.find('mobile') != -1 or column.find('year') != -1 or column.find('month') != -1 or column.find('day') != -1):
                                nn_columns['non_selected'].append(column)
                        elif ['b', 'O', 'S', 'U'].__contains__(column_type):
                            if column.lower().find('city') != -1 or column.lower().find('state') != -1 or column.lower().find('country') != -1 or column.lower().find('gender') != -1 or column.lower().find('sex') != -1:
                                nn_columns['non_selected'].append(column)
                                nn_discrete_columns.append(column)

        if sum(flags_nn) > 1:
            raise Exception("Only one model can be called in the same table")
        if model:
            if not is_test:
                df_nn = self.generate_table_nn(
                    model, df, nn_columns, nn_discrete_columns, num_samples, nn_dest_columns, bias_info=bias)
            else:
                df_nn = self.generate_fake_table_nn(df, nn_columns, nn_discrete_columns, num_samples, nn_dest_columns)
        

        df = self.calculate_dependent_fields(df, all_deps)
        # df_nn = self.calculate_dependent_fields(df_nn, all_deps)

        df.attrs.update(hidden_data)
        df_nn.attrs.update(hidden_data)

        return df, df_nn

    def generate_syn_data_new(self, source_column, destination_column, tokenization_type, df, strategy_id, pattern_id, dependent_fields, pattern=None, faker=None, column_test=False):
        ddf=df
        if faker:
            self.faker_obj = faker_service.FakerService(faker)
        syn_value = None
        constraints = None
        column_strategy = ""
        post_dep_flag = False
        if strategy_id:
            # fetching strategy detils]
            if tokenization_type == 'NA':
                
                column_strategy = stg.get_strategies_id_by_id(strategy_id)
                constraints = stg.get_constraints_by_id(strategy_id)
                if column_strategy == 92 and constraints == "{}":
                    try:
                        df[source_column]=pd.to_datetime(df[source_column])    
                        constraints = '{"startDate":"'+str(df[source_column].min())+'","endDate":"'+str(df[source_column].max())+'"}'
                    except:
                        raise Exception("Can't able to convert data type of selected column to datetime")
                    # for List Auto
                    if column_strategy == 82 and constraints == "{}":
                        # to save time in column test computation
                        if column_test:
                            try:
                                ddf = df.sample(10)

                            except:
                                ddf = df.sample(10, replace=True)
                        else:
                            ddf = df
                        ddf.reset_index(inplace=True, drop=True)

                        constraints = create_biglist_for_listauto(
                            ddf, source_column, faker)
                if not column_strategy:
                    raise Exception(f"unable to find strategy ")

                if column_test:
                    df = ddf.sample(1)
                
                df[f'{source_column}_source_col'] = df[f'{source_column}']
                source_dep_col = []
                destin_dep_col = []
                desti_col = []
                df_type = "str" if isinstance(dependent_fields, str) else "list" ##type(dependent_fields)._name_
                if dependent_fields and dependent_fields != 'None':
                    try:
                        if df_type == 'str':
                            dpjson = json.loads(dependent_fields)
                            if isinstance(dpjson, list):
                                for ddpjson in dpjson:
                                    if "expression" not in ddpjson:
                                        for dp_col in ddpjson:
                                            for col in dp_col:
                                                if col == 'column_name':
                                                    source_dep_col.append(
                                                        f"{dp_col[col]}_source_col")
                                                    destin_dep_col.append(
                                                        f"{dp_col[col]}_destination_col")
                                                    df[f"{dp_col[col]}_source_col"] = df[dp_col[col]]
                                    else:
                                        post_dep_flag=True
                                        post_dependencies={}
                                        dict_final = {ddpjson['column_name']: ddpjson['expression']}
                                        mod_fields = update_dict_connections(post_dependencies, dict_final)

                        elif df_type == 'list':
                            for dp_cols in dependent_fields:
                                if "expression" not in dp_cols:
                                    for dp_col in dp_cols:
                                        if dp_col == 'column_name':
                                            source_dep_col.append(
                                                f"{dp_cols[dp_col]}_source_col")
                                            destin_dep_col.append(
                                                f"{dp_cols[dp_col]}_destination_col")
                                            df[f"{dp_cols[dp_col]}_source_col"] = df[dp_cols[dp_col]]
                                else:
                                    post_dep_flag=True
                                    post_dependencies={}
                                    dict_final = {dp_cols['column_name']: dp_cols['expression']}
                                    mod_fields = update_dict_connections(post_dependencies, dict_final)
                    except:
                        raise Exception("Problem while parsing dependent field.")
                                
                    for dep_col in destin_dep_col:
                        df[dep_col] = ""
                        desti_col.append(dep_col)
                desti_col.insert(
                    0, f'{destination_column}_destination_col')
                df[f'{destination_column}_destination_col'] = ""

                return_values = []

                idxs = list(df.index)
                df.reset_index(inplace=True, drop=True)

                meta = MetaData(df, column_strategy)
                for i, data_value in enumerate(df[f'{source_column}'].to_list()):
                    meta.set_data_value(data_value)
                    if 'race' in meta.dep_fields:
                        meta.set_race_val(df.iloc[i][meta.race])

                    if 'gender' in meta.dep_fields:
                        meta.set_gender_val(df.iloc[i][meta.gender])

                    if column_strategy == 82:
                        data_value = (data_value, idxs[i])
                    return_values.append(self.generate_syn_data(
                        data_value, column_strategy, constraints, dependent_fields, source_column, tokenization_type, metadata=meta))
                ind = -1
                for rvalues in return_values:
                    ind = ind+1
                    for cols in rvalues:
                        for col in cols:
                            if col in desti_col:
                                df[col][ind] = cols[col]
        else:

            if pattern:
                tokenization_type = pattern['tokenization_type']
                delimiter_value = pattern['delimiter_value']
                columnlets_pattern = pattern['columnlets_pattern']
            else:
                tokenization_type = ptn.get_pattern_tokenization_type_by_id(pattern_id)
                delimiter_value = ptn.get_pattern_delimiter_value_by_id(pattern_id)
                columnlets_pattern = json.loads(ptn.get_pattern_columnlets_pattern_by_id(pattern_id))
            df[f'{source_column}_source_col'] = df[f'{source_column}']
            plist = 0
            for col_pattern in columnlets_pattern:
                if col_pattern:
                    strategy_id = col_pattern['strategy_id']
                    dependent_fields = col_pattern['dependent_fields']

                    column_strategy = stg.get_strategies_id_by_id(strategy_id)
                    constraints = stg.get_constraints_by_id(strategy_id)
                    if column_strategy == 92 and constraints == "{}":
                        try:
                            df[source_column]=pd.to_datetime(df[source_column])    
                            constraints = '{"startDate":"'+str(df[source_column].min())+'","endDate":"'+str(df[source_column].max())+'"}'
                        except:
                            raise Exception("Can't able to convert data type of selected column to datetime")
                        
                    if not column_strategy:
                        raise Exception(f"unable to find strategy")
                    source_dep_col = []
                    destin_dep_col = []
                    desti_col = []
                    df_type = "str" if isinstance(dependent_fields, str) else "list" ##type(dependent_fields)._name_
                    if dependent_fields and dependent_fields != 'None':
                        try:
                            if df_type == 'str':
                                dpjson = json.loads(dependent_fields)
                                if isinstance(dpjson, list):
                                    for ddpjson in dpjson:
                                        if "expression" not in ddpjson:
                                            for dp_col in ddpjson:
                                                for col in dp_col:
                                                    if col == 'column_name':
                                                        source_dep_col.append(
                                                            f"{dp_col[col]}_source_col")
                                                        destin_dep_col.append(
                                                            f"{dp_col[col]}_destination_col")
                                                        df[f"{dp_col[col]}_source_col"] = df[dp_col[col]]
                                        else:
                                            post_dep_flag=True
                                            post_dependencies={}
                                            dict_final = {ddpjson['column_name']: ddpjson['expression']}
                                            mod_fields = update_dict_connections(post_dependencies, dict_final)
                            elif df_type == 'list':
                                for dp_cols in dependent_fields:
                                    if "expression" not in dp_cols:
                                        for dp_col in dp_cols:
                                            if dp_col == 'column_name':
                                                source_dep_col.append(
                                                    f"{dp_cols[dp_col]}_source_col")
                                                destin_dep_col.append(
                                                    f"{dp_cols[dp_col]}_destination_col")
                                                df[f"{dp_cols[dp_col]}_source_col"] = df[dp_cols[dp_col]]
                                    else:
                                        post_dep_flag=True
                                        post_dependencies={}
                                        dict_final = {dp_cols['column_name']: dp_cols['expression']}
                                        mod_fields = update_dict_connections(post_dependencies, dict_final)
                        except:
                            raise Exception("Problem while parsing dependent field.")

                        for dep_col in destin_dep_col:
                            df[dep_col] = ""
                            desti_col.append(dep_col)
                    desti_col.insert(
                        0, f'{destination_column}_destination_col')
                    if plist == 0:
                        df[f'{destination_column}_destination_col'] = ""

                    return_values = []
                    meta = MetaData(df, column_strategy)
                    if plist == 0:
                        for data_value in df[f'{source_column}']:
                            syn_value = data_value
                            if tokenization_type == 'fixed':
                                return_values.append(self.columnlet_split_fixed(str(
                                    syn_value), column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                            elif tokenization_type == 'variable':
                                return_values.append(self.columnlet_split_variable(str(
                                    syn_value), delimiter_value, column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                    if plist != 0:
                        for data_value in df[f'{destination_column}_destination_col']:
                            syn_value = data_value
                            if tokenization_type == 'fixed':
                                return_values.append(self.columnlet_split_fixed(str(
                                    syn_value), column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                            elif tokenization_type == 'variable':
                                return_values.append(self.columnlet_split_variable(str(
                                    syn_value), delimiter_value, column_strategy, col_pattern, constraints, dependent_fields, source_column, tokenization_type))
                    plist = plist+1
                    ind = -1
                    for rvalues in return_values:
                        ind = ind+1
                        for cols in rvalues:
                            for col in cols:
                                if col in desti_col:
                                    df[col][ind] = cols[col]
        
        self.meta_register.add_new(source_column, meta)
        if post_dep_flag:
            return df, post_dependencies, mod_fields
        return df, None, None

    def columnlet_split_variable(self, input_value, delimiter_value, strategy_name, pattern, constraints, dependent_fields, source_column, tokenization_type):

        result = []
        if not self.faker_obj.is_nanvalue(input_value):
            out_value = input_value
            if input_value.find(delimiter_value) != -1:
                source_value = out_value.split(delimiter_value)
            else:
                source_value = out_value.split("/")
            # source_value = out_value.split(delimiter_value)
            variable_position = int(pattern['variable_position'])

            new_value = self.generate_syn_data(
                source_value[variable_position-1], strategy_name, constraints, dependent_fields, source_column, tokenization_type)
            source_value[variable_position-1] = new_value[0]
            if strategy_name in [44, 45, 46]:
                for i in range(0,len(source_value)):
                    if source_value[i].find('00:00:00'):
                        source_value[i]=source_value[i].replace(" 00:00:00","")
                new_value = correct_date(source_value)
            out_value = delimiter_value.join(source_value)
            result.append({source_column+"_destination_col": out_value})
            if dependent_fields != 'None' and dependent_fields and len(new_value) > 1:
                result.append(new_value[1])
        else:
            result.append({source_column+"_destination_col": str(input_value)})
        return result

    def columnlet_split_fixed(self, input_value, strategy_name, config, constraints, dependent_fields, source_column, tokenization_type):
        result = []
        if not self.faker_obj.is_nanvalue(input_value):
            out_value = input_value[:]
            # config = sorted(config, key=lambda d: d['position_range_start'], reverse=True)
            is_checksum = False
            # for config in configs:

            if strategy.checksum.value == strategy_name:
                is_checksum = True
            else:
                position_range_start = int(config['position_range_start'])-1
                position_range_end = int(config['position_range_end'])
                actual_value = out_value[position_range_start:position_range_end]

                new_value = self.generate_syn_data(
                    actual_value, strategy_name, constraints, dependent_fields, source_column, tokenization_type)
                out_value = out_value[:position_range_start] + \
                    out_value[position_range_end:]
                out_value = list(out_value)
                if len(new_value[0]) == len(actual_value):
                    out_value.insert(position_range_start, new_value[0])
                else:
                    out_value.insert(
                        position_range_start, new_value[0][-(position_range_end-position_range_start):])

                out_value = "".join(out_value)
            if is_checksum:
                out_value = self.faker_obj.checksum(out_value, source_column)
                result = out_value
            else:
                result.append({source_column+"_destination_col": out_value})
            if dependent_fields != 'None' and dependent_fields and len(new_value) > 1:
                result.append(new_value[1])
        else:
            result.append({source_column+"_destination_col": str(input_value)})
        return result

    def generate_syn_data(self, attribute_value, attribute_type, constraints, dependent_fields, source_column, tokenization_type, metadata=None):
        syn_value = None
        result = []
        if self.faker_obj is not None:
            # syn_value = attribute_value
            # if self.faker_obj.locale != 'en-ZA':
            if attribute_type == strategy.date_of_birth.value:

                c_values = json.loads(constraints)
                cons = str(c_values)
                days_before = days_after = 10
                limit_to_current_date = 'true'
                date_format = data_type = ""
                if c_values:
                    if cons.find('daysBefore') != -1:
                        days_before = c_values['daysBefore']
                    if cons.find('daysAfter') != -1:
                        days_after = c_values['daysAfter']
                    if cons.find('limitToCurrentDate') != -1:
                        limit_to_current_date = c_values['limitToCurrentDate']
                    if not limit_to_current_date or str(limit_to_current_date).lower() == 'true':
                        limit_to_current_date = True
                    else:
                        limit_to_current_date = False
                    if cons.find('dateFormat') != -1:
                        date_format = c_values['dateFormat']
                    if not date_format:
                        date_format = ""
                    if cons.find('dataType') != -1:
                        data_type = c_values['dataType']
                    if not data_type:
                        data_type = "string"
                    syn_value = self.faker_obj.generate_date_of_birth(
                        attribute_value, date_format=date_format, days_before=days_before, days_after=days_after, limit_to_current_date=limit_to_current_date, data_type=data_type)
                else:
                    syn_value = self.faker_obj.generate_date_of_birth(
                        attribute_value, "")
                    # Date retain format logic
                    # syn_value = self.faker_obj.faker.date_of_birth()
                    # self.dformat = self.faker_obj.detect_date_format(str(attribute_value))
                    # if self.dformat == "Format not detected":
                    #     self.dformat="%Y-%m-%d"
                    # syn_value = syn_value.strftime(self.dformat)
                if tokenization_type == "NA":
                    result.append(
                        {source_column+"_destination_col": syn_value})
                else:
                    result.append(syn_value)
                return result
            elif attribute_type == strategy.date_range.value:
                syn_value = self.faker_obj.generate_date_range(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.person_name.value:  # 'person_name':
                syn_value = self.faker_obj.generate_person_name(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.oai_person_name.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type, metadata)
            elif attribute_type == strategy.first_name.value:
                syn_value = self.faker_obj.generate_first_name(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.last_name.value:
                syn_value = self.faker_obj.generate_last_name(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.gender.value:
                syn_value = self.faker_obj.generate_gender(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.state.value:
                syn_value = self.faker_obj.generate_state(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.state_code.value:
                syn_value = self.faker_obj.generate_state_abbr(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.city.value:
                syn_value = self.faker_obj.generate_city(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.street_name.value:
                syn_value = self.faker_obj.generate_street_name(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.building_number.value:
                syn_value = self.faker_obj.generate_building_number(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.street_address.value:
                syn_value = self.faker_obj.generate_street_address(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.address_line2.value:
                syn_value = self.faker_obj.generate_address_line2(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.postal_code.value:
                syn_value = self.faker_obj.generate_postal_code(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.zip_code.value:
                syn_value = self.faker_obj.generate_zip_code(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.address.value:
                syn_value = self.faker_obj.generate_address(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.oai_address.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.phone_number.value:
                syn_value = self.faker_obj.generate_phone_number(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.telephone_number.value:
                syn_value = self.faker_obj.generate_telephone_number(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.ssn.value:
                syn_value = self.faker_obj.generate_ssn(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.random_number.value:
                syn_value = self.faker_obj.generate_random_number(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.random_letters.value:
                syn_value = self.faker_obj.generate_random_letter(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.random_alpha_numeric.value:
                syn_value = self.faker_obj.generate_random_alpha_numeric(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.license_plate.value:
                syn_value = self.faker_obj.generate_license_plate(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.job.value:
                syn_value = self.faker_obj.generate_job(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.personal_email.value:
                syn_value = self.faker_obj.generate_personal_email(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.company_email.value:
                syn_value = self.faker_obj.generate_company_email(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.ipv4_address.value:
                syn_value = self.faker_obj.generate_ipv4_address(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.ipv6_address.value:
                syn_value = self.faker_obj.generate_ipv6_address(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.device_address.value:
                syn_value = self.faker_obj.generate_device_address(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.domain_name.value:
                syn_value = self.faker_obj.generate_domain_name(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.credit_card.value:
                syn_value = self.faker_obj.generate_credit_card(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.credit_card_type.value:
                syn_value = self.faker_obj.generate_credit_card_type(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.credit_card_expiry_date.value:
                syn_value = self.faker_obj.generate_credit_card_expiry_date(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.bank_account.value:
                syn_value = self.faker_obj.generate_bank_account(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.swift_code.value:
                syn_value = self.faker_obj.generate_swift_code(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.company_name.value:
                syn_value = self.faker_obj.generate_company_name(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.barcode.value:
                syn_value = self.faker_obj.generate_barcode(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.color.value:
                syn_value = self.faker_obj.generate_color(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.land_coordinates.value:
                syn_value = self.faker_obj.generate_land_coordinates(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.currency.value:
                syn_value = self.faker_obj.generate_currency(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.date_time.value:
                syn_value = self.faker_obj.generate_date_time(
                    attribute_value, source_column, constraints, tokenization_type)
            elif attribute_type == strategy.year.value:
                syn_value = self.faker_obj.generate_year(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.month_number.value:
                syn_value = self.faker_obj.generate_month(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.day_number.value:
                syn_value = self.faker_obj.generate_day_number(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.personal_profile.value:
                syn_value = self.faker_obj.generate_personal_profile(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.checksum.value:
                syn_value = self.faker_obj.checksum(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.date_number.value:
                syn_value = self.faker_obj.generate_date_number(
                    attribute_value, constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.regex_pattern.value:
                syn_value = self.faker_obj.generate_regs(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.list.value:
                syn_value = self.faker_obj.control_list(
                    attribute_value, constraints, source_column, tokenization_type)
            elif attribute_type == strategy.list_auto.value:
                syn_value = list_auto_func(
                    attribute_value, constraints, source_column, tokenization_type, is_new=False)

            # elif self.faker_obj.locale == 'en-ZA':
            elif attribute_type == strategy.said.value:
                syn_value = self.faker_obj.ZA_generate_said(
                    attribute_value, source_column, dependent_fields, None, tokenization_type)
            elif attribute_type == strategy.oai_first_name.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type, metadata)
            elif attribute_type == strategy.oai_last_name.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type, metadata)
            elif attribute_type == strategy.oai_address.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.oai_street_name.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.oai_city.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type)
            elif attribute_type == strategy.oai_province.value:
                syn_value = oi.generate_query(self.faker_obj.locale, attribute_type, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type)
            elif self.faker_obj.locale == 'en-ZA' and attribute_type == strategy.country.value:
                result = []
                if tokenization_type == 'NA':
                    result.append(
                        {source_column+"_destination_col": "South Africa"})
                else:
                    result.append("South Africa")
                syn_value = result
            elif attribute_type == strategy.country.value:
                syn_value = self.faker_obj.generate_country(
                    attribute_value, source_column, tokenization_type)
            elif attribute_type == strategy.PII_PHI_Redaction.value:
                if self.faker_obj.is_nanvalue(attribute_value):
                    attribute_value = ""
                if "[PHI]" not in attribute_value:
                    masked = mask_text_PII_PHI(attribute_value if attribute_value else "")
                else:
                    masked = attribute_value
                if tokenization_type == "NA":
                    result.append(
                        {source_column+"_destination_col": masked})
                else:
                    result.append(masked)
                syn_value = result
            elif attribute_type == strategy.retain.value:
                if tokenization_type == "NA":
                    result.append(
                        {source_column+"_destination_col": attribute_value})
                else:
                    result.append(attribute_value)
                syn_value = result
            # else:
            #     raise Exception (f"Locale not assigned")
            return syn_value
        else:
            raise Exception(f"Faker is not initialized")

    def find_ondelete_cascade(self, source_engine, source_schema, source_table, pk_column, driver_name):
        del_rule = 0
        db = sdb
        if len(pk_column) >= 1:
            if driver_name.lower() == "mssql":
                delete_rule = db.get_column_relations_child_mssql(
                    source_engine, source_schema, source_table, pk_column)
            elif driver_name.lower() == "mysql":
                delete_rule = db.get_column_relations_child_mysql(
                    source_engine, source_schema, source_table, pk_column)
            elif driver_name.lower() == "oracle":
                delete_rule = db.get_column_relations_child_oracle(
                    source_engine, source_schema, source_table, pk_column)
            elif driver_name.lower() == "ibmdb2":
                delete_rule = db.get_column_relations_child_ibmdb2(
                    source_engine, source_schema, source_table, pk_column)
            elif driver_name.lower() == "postgresql":
                delete_rule = db.get_column_relations_child_postgres(
                    source_engine, source_schema, source_table, pk_column)

            delete_rule_df = delete_rule.to_json(orient='records')
            if delete_rule_df:
                del_rule = json.loads(delete_rule_df)
                for json_del_rul in del_rule:
                    del_rule_val = json_del_rul['DELETE_RULE']
                    if del_rule_val == 'NO ACTION':
                        del_rule = 1
        return del_rule

    def find_onupdate_cascade(self, source_engine, source_schema, source_table, parent_table, pk_column, driver_name, db):
        update_rule = 0
        if len(pk_column) >= 1:
            # if source_table != parent_table:
            if driver_name.lower() == "mssql":
                delete_rule = db.get_column_relations_child_mssql(
                    source_engine, source_schema, parent_table, pk_column)
            elif driver_name.lower() == "mysql":
                delete_rule = db.get_column_relations_child_mysql(
                    source_engine, source_schema, parent_table, pk_column)
            elif driver_name.lower() == "oracle":
                delete_rule = db.get_column_relations_child_oracle(
                    source_engine, source_schema, parent_table, pk_column)
            elif driver_name.lower() == "ibmdb2":
                delete_rule = db.get_column_relations_child_ibmdb2(
                    source_engine, source_schema, parent_table, pk_column)
            elif driver_name.lower() == "postgresql":
                delete_rule = db.get_column_relations_child_postgres(
                    source_engine, source_schema, parent_table, pk_column)

            delete_rule_df = delete_rule.to_json(orient='records')
            if delete_rule_df:
                del_rule = json.loads(delete_rule_df)
                for json_del_rul in del_rule:
                    del_rule_val = json_del_rul['update_rule']
                    if del_rule_val == 'CASCADE':
                        update_rule = 1
                        break
                    elif del_rule_val == 'NO ACTION' and source_table == json_del_rul['table_name']:
                        update_rule = 0
                    else:
                        update_rule = 0

        return update_rule
    
    def generate_fake_table_nn(self, df, nn_columns, categorical_features, num_samples, destination_columns):
        chosen_columns = nn_columns['selected']
        non_chosen = nn_columns['non_selected']
        all_col = chosen_columns + non_chosen
        df_nn = pd.DataFrame()
        df_1 = df[all_col]
        metadata = SingleTableMetadata()
        metadata.detect_from_dataframe(df_1)
        # handle_nulls_mean(df_1, categorical_features)
        r_sample = {}
        for col in df_1.columns:
            if metadata.columns[col]['sdtype'] == 'numerical':
                mean = df_1[col].mean()
                std = df_1[col].std()
                r_sample[col] = np.random.normal(mean,std,num_samples)
                if df_1[col].dtype.kind == 'i':
                    r_sample[col] = np.round(r_sample[col], decimals=0)
            elif metadata.columns[col]['sdtype'] == 'categorical':
                r_sample[col] = random.choices(df_1[col], k=num_samples)
        r_sample = pd.DataFrame.from_dict(r_sample)
        if len(df.index) < num_samples:
            df_nn = r_sample.tail(num_samples-len(df.index))
            r_sample = r_sample.head(len(df.index))
        for source_column, destination_column in zip(chosen_columns, destination_columns):
            df[f'{source_column}_source_col'] = df[f'{source_column}']
            df[f'{destination_column}_destination_col'] = r_sample[f'{source_column}']
        return df_nn

    def generate_table_nn(self, model, df, nn_columns, categorical_features, num_samples, destination_columns, bias_info):
        chosen_columns = nn_columns['selected']
        non_chosen = nn_columns['non_selected']
        all_col = chosen_columns + non_chosen
        df_nn = pd.DataFrame()
        df_1 = df[all_col]
        metadata = SingleTableMetadata()
        metadata.detect_from_dataframe(df_1)
        # handle_nulls_mean(df_1, categorical_features)
        if model == 'CTGAN':
            model_obj = CTGANSynthesizer(metadata)
        elif model == 'CopulaGAN':
            model_obj = CopulaGANSynthesizer(metadata)
        elif model == 'Transformer':
            model_obj = REaLTabFormer(model_type="tabular",
                                      gradient_accumulation_steps=4, logging_steps=100)
        elif model == 'TVAE':
            model_obj = TVAESynthesizer(metadata)
        
        elif model == 'NoGAN':
            model_obj = NoGAN(df_1)

        if model == 'Transformer':
            model_obj.fit(df_1, device='cpu')
            r_sample = model_obj.sample(n_samples=num_samples, device="cpu")
        elif model == 'NoGAN':
            model_obj.fit()
            r_sample = model_obj.sample(num_samples)
        else:
            if model != "TVAE" and bool(bias_info):  # only works with copula and CTGAN
                S = bias_info['S']
                Y = bias_info['Y']
                underprivileged_value = bias_info['underprivileged_value']
                desirable_value = bias_info['desirable_value']
                model_obj.fit(df_1, command="with_fairness", S=S, Y=Y,
                              underprivileged_value=underprivileged_value, desirable_value=desirable_value)
            else:
                model_obj.fit(df_1)
            r_sample = model_obj.sample(num_samples)
        if len(df.index) < num_samples:
            df_nn = r_sample.tail(num_samples-len(df.index))
            r_sample = r_sample.head(len(df.index))
        for source_column, destination_column in zip(chosen_columns, destination_columns):
            df[f'{source_column}_source_col'] = df[f'{source_column}']
            df[f'{destination_column}_destination_col'] = r_sample[f'{source_column}']
        return df_nn

    def convert_df_object_varchar2(self, dframe, length=256):
        cols = dframe.select_dtypes(include='object')
        dtyps = {col: sq.types.VARCHAR(255) for col in cols}
        return dtyps

    def generate_data_from_job_file(self, file_content, config, is_test=False, test_rows=None,file_ext=None,table_data=None,locale=None,bias=None):

        return_status = 'success'
        newdf = pd.DataFrame()
        mdf = pd.DataFrame()
        df_nn = pd.DataFrame()
        sc = ""
        dc = ""
       
        try:
            column_config=config
            
            if is_test:
                row_limit = test_rows
                self.faker_obj = faker_service.FakerService(locale)
                df=file_content.copy()
                ### for json nexted data only #####
                if file_ext in [".json",".xml"]:
                    decompossed_cols = []
                    for c in df.columns:
                        if c.startswith('**'):
                            df = df.drop(columns=[c], axis=1)
                            decompossed_cols = c.strip('**').split('|-')
                            break
                    df.attrs['dict_'] = decompossed_cols
                attrs = None
                if file_ext == '.xml':
                    attrs = df.attrs['hidden_data']
                table_rows_count = df.shape[0]
                if is_test and df.shape[0] == 0:
                    d = {}
                    for col in df.columns:
                        d[col] = ""
                    df = pd.DataFrame([d]*10)
                    df.reset_index(inplace=True, drop=True)
                    if is_test:
                        before=file_content.copy()
                columns_list = df.columns.to_list()
                column_types = df.dtypes
                number_samples = row_limit
                if not table_data:
                    if int(table_rows_count) >= 0:

                        # getting data modiftion by limited rows
                        if table_rows_count > number_samples:
                            df = df.sample(number_samples)
                            df.reset_index(inplace=True, drop=True)
                        if is_test:
                            before=file_content.copy()
                        mdf, df_nn = self.generation_columns_synthatic_data(
                            None, column_config, None, None, None, None, number_samples, None, columns_list, is_file=True, df=df, locale=locale, is_test=is_test, bias=bias)
                        source_column = [
                            col for col in mdf.columns if 'source_col' in col]
                        destination_column = [
                            col for col in mdf.columns if 'destination_col' in col]
                        zip_postal_code = find_zip(source_column)
                        if zip_postal_code != -1:
                            if str(mdf[zip_postal_code].dtype) == 'float64':
                                mdf[zip_postal_code] = mdf[zip_postal_code].astype(
                                    'int')
                        del_col = []
                        for column in mdf.columns:
                            if column.__contains__('_source_col'):
                                del_col.append(column)
                            if column.__contains__('_destination_col'):
                                del_col.append(column)
                                mdf[column.replace(
                                    "_destination_col", "")] = mdf[column]
                        mdf.drop(columns=del_col, axis=1, inplace=True)
                        sc = ", ".join(source_column)
                        sc = sc.replace("_source_col", "")
                        dc = ", ".join(destination_column)
                        dc = dc.replace("_destination_col", "")
                    if (int(table_rows_count) < int(row_limit)) and not is_test:
                        if not df_nn.empty:
                            positions = {}
                            columns_list_aux = columns_list.copy()
                            for i, col in enumerate(columns_list):
                                if df_nn.columns.__contains__(col):
                                    columns_list_aux.remove(col)
                                    positions[col] = i
                            columns_list = columns_list_aux
                        # newdf = self.generate_new_data_old(pd.DataFrame(), None, None, None, None, None, columns_list, row_limit - int(
                        #     table_rows_count), None, None, None, column_types, mdf, True)
                        newdf = self.generate_new_data(pd.DataFrame(), None, None, None, None, None, columns_list, row_limit - int(
                            table_rows_count), None, None, None, column_types, None, mdf, column_config, True, faker=locale, nn_df=df_nn)
                        
                        newdf.attrs['connection_map'] = mdf.attrs['connection_map'] if 'connection_map' in mdf.attrs else {}
                        newdf = self.calculate_dependent_fields_newdata(
                            newdf, mdf.attrs['all_deps'], mdf.attrs['all_dep_cols'])

                        if not df_nn.empty:
                            for col in positions:
                                x = df_nn[col].values.tolist()
                                newdf.insert(positions[col], col, x)

                        mdf = pd.concat([mdf, newdf])

                        if file_ext == ".json":
                            mdf.attrs['dict_'] = df.attrs['dict_']
                else:
                    if is_test:
                        before = file_content.copy()
                    if table_rows_count > number_samples:
                        df = df.head(number_samples)
                    table_data1 = json.loads(table_data)
                    rule_id = table_data1['rule_id']
                    input_fields = table_data1['input_fields']

                    if len(input_fields):
                        url = "rule.url"
                    else:
                        # rule = db_session.query(SyntheticDataDroolsFile).filter(SyntheticDataDroolsFile.id == rule_id).first()
                        url=None
                    
                    ########## Calling rules ################
                    if url:
                        mdf = self.generate_drolls_data(df, input_fields, url)
                    else:
                        ruleName = "rule.ruleName"
                        mdf = self.generate_custom_drools(df, ruleName, "File")
                    
                    mdf.attrs = df.attrs
                    sc = ""
                    dc = ""

        except Exception as e:
            return_status = 'failed'
            raise Exception(e)

        return before,mdf
        
    def generate_drolls_data(self, sdf, input_fields, url):
        column1 = sdf.columns[0]
        newdf = sdf
        finaldf = pd.DataFrame()
        for i in range(len(sdf)):
            result = de.rule_handler(1, input_fields, newdf.head(1), url)
            if isinstance(result, dict):
                offer = result['offers']
                resulfdf = pd.json_normalize(offer)
                resulfdf.insert(0, column1, sdf[f'{column1}'][i])
                # resultjson = resulfdf.to_json(orient='records')
                if len(finaldf) >= 1:
                    finaldf = pd.concat([finaldf, resulfdf], ignore_index=True)
                else:
                    finaldf = resulfdf
            else:
                if len(finaldf) >= 1:
                    new_row = {f'{column1}': sdf[f'{column1}'][i]}
                    finaldf.loc[len(finaldf)] = new_row
                else:
                    finaldf.columns = sdf.columns
                    finaldf.insert(0, column1, sdf[f'{column1}'][i])
            newdf = newdf[1:]
        return finaldf
    
    def generate_custom_drools(self, sdf, ruleName, source):
        finaldf = pd.DataFrame()
        for i, row in sdf.iterrows():
            row = row.to_dict()    
            result = de.drools_file_rule_handler(row, {"ruleName": ruleName}, source)
            finaldf = finaldf.append(result, ignore_index=True)
        return finaldf


    def get_dependent_val_for_name_and_race(self, col, df, nn_df):
        dff = df if col in df.columns else nn_df
        return dff[col].to_list()
    
    
    # def anomaly_detection(self, client, db_session, job_id, execution_id):

    #     return_status = 'success'
    #     newdf = pd.DataFrame()
    #     mdf = pd.DataFrame()
    #     df_nn = pd.DataFrame()
    #     sc = ""
    #     dc = ""

    #     try:
    #         # fetching job details
    #         # with session_scope() as db_session:
    #         job = db_session.query(SyntheticDataJobSql, SyntheticDataSubJob).join(
    #             SyntheticDataJobSql, SyntheticDataSubJob.job_id == SyntheticDataJobSql.id).filter(SyntheticDataSubJob.job_id == job_id).first()
    #         if job:
    #             d_b = client['bruData']
    #             collection = d_b['JobFiles']
    #             project_id = job.SyntheticDataJobSql.project_id
    #             modified_by = job.SyntheticDataJobSql.created_by
    #             row_limit = job.SyntheticDataJobSql.row_limit
    #             locale = job.SyntheticDataJobSql.locale
    #             qr = job.SyntheticDataSubJob
    #             anomalies = qr.anomalies
    #             file_ext = qr.file_extension
    #             self.faker_obj = faker_service.FakerService(locale)
    #             if qr.source_connection:
    #                 dbconnection = db_session.query(SyntheticDataConnections).filter(
    #                     SyntheticDataConnections.id == int(qr.source_connection)).first()
    #                 driver_name = dbconnection.driver_name.lower()
    #                 source_table = qr.source_table
    #                 source_schema = qr.source_schema
    #                 db = set_db_operation(driver_name)
    #                 engine = db.create_db_connection_from_table(
    #                     db_session, qr.source_connection)
    #                 if driver_name == 'salesforce':
    #                     columns_list = db.get_columns_names(
    #                         engine, source_table)
    #                     query = f'select  {columns_list}  from {source_table}'
    #                 else:
    #                     query = f'SELECT * FROM {qr.source_schema}.{qr.source_table}'
    #                 df = db.get_sql_to_df(engine, query)
    #             elif qr.source_file:
    #                 with client.start_session() as session:
    #                     with session.start_transaction():
    #                         file = collection.find_one(
    #                             {"_id": ObjectId(qr.source_file)}, {"_id": 0})
    #                 df = utils.transform_file_type(file, file_ext)
    #             else:
    #                 raise Exception("No input table information was given")
                                
    #             ### for json nexted data only #####
    #             if file_ext in [".json",".xml"]:
    #                 decompossed_cols = []
    #                 for c in df.columns:
    #                     if c.startswith('**'):
    #                         df = df.drop(columns=[c], axis=1)
    #                         decompossed_cols = c.strip('**').split('|-')
    #                         break
    #                 df.attrs['dict_'] = decompossed_cols
    #             attrs = None
    #             if file_ext == '.xml':
    #                 attrs = df.attrs['hidden_data']
    #             table_rows_count = df.shape[0]
    #             columns_list = df.columns.to_list()
    #             column_types = df.dtypes

    #             data_transformer = DataTransformer()
    #             metadata = SingleTableMetadata()
    #             metadata.detect_from_dataframe(df)
    #             discrete_columns = detect_discrete_columns(metadata, df)
    #             data_transformer.fit(df, discrete_columns)
    #             X = data_transformer.transform(df)
    #             if anomalies['target']:
    #                 y = df.pop(anomalies['target']).to_numpy()
    #                 X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.2)
    #             else:
    #                 X_train, X_test = train_test_split(X, test_size=0.2, shuffle=False)

    #             if anomalies['target']:
    #                 model = DevNet(device='cpu')
    #                 model.fit(X_train, y=y_train)
    #             else:
    #                 model = DeepSVDD(device='cpu')
    #                 model.fit(X_train, y=None)
                
    #             test_df = data_transformer.inverse_transform(X_test)
    #             if anomalies['changes']:
    #                 sample = df.sample(row_limit).reset_index(drop=True)
    #                 sample2 = self.generate_new_data(pd.DataFrame(), None, None, None, None, None, columns_list, row_limit, None, None, None, column_types, None, mdf, job_id, True, faker=locale, nn_df=df_nn)
    #                 empty = sample2.applymap(lambda x: x == ' ' or x == '' or x == np.NaN).all()
    #                 for col in sample.columns:
    #                     if not empty[col]:
    #                         sample[col] = sample2[col]
    #                 for col in anomalies['changes']['categorical']:
    #                     sample[col] = [anomalies['changes']['categorical'][col]] * row_limit
    #                 for col in anomalies['changes']['numeric']:
    #                     rango = anomalies['changes']['numeric'][col]
    #                     values = np.random.uniform(rango[0], rango[1], row_limit)
    #                     sample[col] = values
    #                 test_df = pd.concat([test_df, sample]).reset_index(drop=True)
                
    #             X_test = data_transformer.transform(test_df)
    #             predictions = model.predict(X_test)

    #             test_df['brew_anom_pred'] = predictions
    #             mdf = test_df

    #             if file_ext == ".json":
    #                 mdf.attrs['dict_'] = df.attrs['dict_']

    #             temp = utils.inverse_transform_file_type(
    #                 mdf, '.csv', attrs, True)
    #             destin_file = None
    #             with client.start_session() as session:
    #                 with session.start_transaction():
    #                     destin_file = collection.insert_one(
    #                         temp).inserted_id
    #             db_session.query(SyntheticDataSubJob).filter_by(
    #                 job_id=job_id).update({'destination_file': destin_file})

    #             em = SyntheticDataJobExecutionMonitor(execution_id, None, None,
    #                                                     sc, dc, None, modified_by, currentGMTTimestamp())

    #             db_session.add(em)
    #             db_session.commit()
    #             sleep(2)


    #     except Exception as e:
    #         return_status = 'failed'
    #         db_session.query(SyntheticDataJobExecution).filter(SyntheticDataJobExecution.id == execution_id).update({'status': str(
    #             utils.ExecutionStatus.errored.name), 'project_id': project_id, 'created_by': modified_by, 'error_text': str(e)[0:990], 'end_time': currentGMTTimestamp(), 'modified_by': modified_by})
    #         db_session.commit()

    #     else:
    #         db_session.query(SyntheticDataJobExecution).filter(SyntheticDataJobExecution.id == execution_id).update({'status': str(
    #             utils.ExecutionStatus.finished.name), 'project_id': project_id, 'created_by': modified_by, 'end_time': currentGMTTimestamp(), 'modified_by': modified_by})
    #         db_session.commit()

    #     return return_status

    def generate_new_data(self, PKdf, engine, db_name, source_schema, source_table, keycolumns, columns_list, norows, identity_key_next_value, driver_name, column_metas, column_types, db, sdf, config, is_file=False, faker=None, nn_df=None):

        row_count = sdf.shape[0]
        df = pd.DataFrame()
        primary_key_df = pd.DataFrame()
        fk_columns = []
        pk_columns = []
        calum_min_max = []
        tablepkcolumn = ""
        
        column_configs = config
        if not is_file:
            if driver_name == 'salesforce':
                tablepkcolumn = db.get_primarykeys(
                    engine, source_table)
                columns_list.remove('Id')
            else:
                tablepkcolumn = db.get_primarykeys(
                    engine, source_schema, source_table)
            if keycolumns:
                for keycolumn in keycolumns:
                    if driver_name == 'mssql':
                        sql_query = f"select  {keycolumn['pk_column_name']} from {db_name}.{keycolumn['pk_schema_name']}.{keycolumn['pk_table_name']} order by {keycolumn['pk_column_name']}"
                    elif driver_name == 'mysql' or driver_name == 'oracle' or driver_name == 'ibmdb2' or driver_name == 'postgresql':
                        sql_query = f"select  {keycolumn['pk_column_name']} from {keycolumn['pk_schema_name']}.{keycolumn['pk_table_name']} order by {keycolumn['pk_column_name']}"
                    elif driver_name == 'salesforce':
                        sql_query = f"select  {keycolumn['pk_column_name']} from {keycolumn['pk_table_name']} order by {keycolumn['pk_column_name']}"

                    newdf = db.get_sql_to_df(engine, sql_query)
                    if newdf.empty:
                        newdf=db.fill_empty_df(newdf,keycolumn['pk_column_name'],0)
                    calum_min_max.append(newdf.shape[0])
                    if primary_key_df.shape[1] == 0:
                        primary_key_df = newdf
                    else:
                        if driver_name == 'salesforce':
                            primary_key_df[keycolumn['fk_column_name']
                                        ] = newdf[keycolumn['pk_column_name']]
                        else:
                            primary_key_df[keycolumn['pk_column_name']
                                        ] = newdf[keycolumn['pk_column_name']]
                    fk_columns.append(keycolumn['fk_column_name'])
                    pk_columns.append(keycolumn['pk_column_name'])
                    fk_table_name = keycolumn['fk_table_name']
                    pk_table_name = keycolumn['pk_table_name']
                pk_value_row_count = primary_key_df.shape[0]
                if fk_table_name == pk_table_name:
                    return df
        strategy_id = None
        column_strategy = None
        constraints = None
        attribute_value = ""
        dependent_fields = ""
        tokenization_type = " "
        source_column = None

        for column in self.meta_register.get_seq(columns_list, nn_df.columns):
            new_value = None
            flag = 0
            #column_type = column_types[column]
            ctype = ''
            source_column = column
            aut_inc = None
            column_strategy = None
            constraints = None
            strategy_id = None
     
            for col in column_configs:
                if column == col['source_column']:
                    strategy_id = col['strategy_id']
                    break

            if strategy_id:
                column_strategy = stg.get_strategies_id_by_id(strategy_id)
                constraints = stg.get_constraints_by_id(strategy_id)
                if column_strategy == 82 and constraints == "{}":
                    constraints = create_biglist_for_listauto(
                        sdf, source_column, faker)
            
            if not is_file:
                column_meta = column_metas[column]
                ctype = str(column_meta['type'])
                if driver_name != 'salesforce':
                    aut_inc = column_meta['autoincrement']
            new_data = []
        
            for i in range(norows):
                if source_column in self.meta_register.map:
                    self.meta_register.map[source_column].set_data_value(None)
                    if 'race' in self.meta_register.map[source_column].dep_fields:
                        self.meta_register.map[source_column].set_race_val(self.get_dependent_val_for_name_and_race(self.meta_register.map[source_column].race, df, nn_df)[i])

                    if 'gender' in self.meta_register.map[source_column].dep_fields:
                        self.meta_register.map[source_column].set_gender_val(self.get_dependent_val_for_name_and_race(self.meta_register.map[source_column].gender, df, nn_df)[i])

                profile = self.faker_obj.faker.profile()
                if column in fk_columns:
                    if fk_table_name != pk_table_name:
                        columnindex = fk_columns.index(column)
                        if primary_key_df.shape[0]>calum_min_max[columnindex]:
                            rn = random.randrange(0, calum_min_max[columnindex])
                        else:
                            rn = random.randrange(0, primary_key_df.shape[0])
                        columnindex = fk_columns.index(column)
                        new_value = primary_key_df[pk_columns[columnindex]][rn]

                elif (ctype == ('uniqueidentifier').upper()):
                    new_value = uuid.uuid4()
                elif column_strategy == strategy.date_of_birth.value:

                    c_values = json.loads(constraints)
                    cons = str(c_values)
                    days_before = days_after = 10
                    limit_to_current_date = 'true'
                    date_format = data_type = ""
                    if c_values:
                        if cons.find('daysBefore') != -1:
                            days_before = c_values['daysBefore']
                        if cons.find('daysAfter') != -1:
                            days_after = c_values['daysAfter']
                        if cons.find('limitToCurrentDate') != -1:
                            limit_to_current_date = c_values['limitToCurrentDate']
                        if not limit_to_current_date or str(limit_to_current_date).lower() == 'true':
                            limit_to_current_date = True
                        else:
                            limit_to_current_date = False
                        if cons.find('dateFormat') != -1:
                            date_format = c_values['dateFormat']
                        if not date_format:
                            date_format = ""
                        if cons.find('dataType') != -1:
                            data_type = c_values['dataType']
                        if not data_type:
                            data_type = "string"
                        new_value = self.faker_obj.generate_date_of_birth(
                            attribute_value, date_format=date_format, days_before=days_before, days_after=days_after, limit_to_current_date=limit_to_current_date, data_type=data_type)
                    else:
                        new_value = self.faker_obj.generate_date_of_birth(
                            attribute_value, "")
                # return new_value
                elif column_strategy == strategy.date_range.value:
                    syn_value = self.faker_obj.generate_range(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.person_name.value:  # 'person_name':
                    syn_value = self.faker_obj.generate_person_name(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.oai_person_name.value:
                    new_value = oi.generate_query(self.faker_obj.locale, column_strategy, attribute_value,
                                                  constraints, dependent_fields, source_column, tokenization_type, self.meta_register.map[source_column])
                    new_value = new_value[0]
                elif column_strategy == strategy.oai_first_name.value:
                    new_value = oi.generate_query(self.faker_obj.locale, column_strategy, attribute_value,
                                                constraints, dependent_fields, source_column, tokenization_type, self.meta_register.map[source_column])
                    new_value = new_value[0]

                elif column_strategy == strategy.oai_last_name.value:
                    new_value = oi.generate_query(self.faker_obj.locale, column_strategy, attribute_value,
                                              constraints, dependent_fields, source_column, tokenization_type, self.meta_register.map[source_column])
                    new_value = new_value[0]

                elif column_strategy == strategy.first_name.value:
                    syn_value = self.faker_obj.generate_first_name(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.last_name.value:
                    syn_value = self.faker_obj.generate_last_name(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.gender.value:
                    syn_value = self.faker_obj.generate_gender(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.state.value:
                    syn_value = self.faker_obj.generate_state(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.state_code.value:
                    syn_value = self.faker_obj.generate_state_abbr(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.city.value:
                    syn_value = self.faker_obj.generate_city(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.street_name.value:
                    syn_value = self.faker_obj.generate_street_name(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.building_number.value:
                    syn_value = self.faker_obj.generate_building_number(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.street_address.value:
                    syn_value = self.faker_obj.generate_street_address(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.address_line2.value:
                    syn_value = self.faker_obj.generate_address_line2(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                elif column_strategy == strategy.postal_code.value:
                    syn_value = self.faker_obj.generate_postal_code(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.zip_code.value:
                    syn_value = self.faker_obj.generate_zip_code(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.country.value:
                    syn_value = self.faker_obj.generate_country(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.address.value:
                    syn_value = self.faker_obj.generate_address(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.oai_address.value:
                    syn_value = oi.generate_query(self.faker_obj.locale, column_strategy, attribute_value,
                                                  constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.phone_number.value:
                    syn_value = self.faker_obj.generate_phone_number(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.telephone_number.value:
                    syn_value = self.faker_obj.generate_telephone_number(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.ssn.value:
                    syn_value = self.faker_obj.generate_ssn(
                        attribute_value, source_column, tokenization_type)
                    if not is_file:
                        if PKdf.shape[0] >= 1:
                            flag = 0
                            while flag == 0:
                                syn_value = self.faker_obj.generate_ssn(
                                    attribute_value, source_column, tokenization_type)
                                if syn_value[0] not in PKdf.to_list():
                                    if new_data:
                                        if syn_value[0] not in new_data:
                                            flag = 1
                                    else:
                                        flag = 1
                    new_value = syn_value[0]
                elif column_strategy == strategy.random_number.value:
                    syn_value = self.faker_obj.generate_random_number(
                        attribute_value, constraints, source_column, tokenization_type)
                    if not is_file:
                        if tablepkcolumn:
                            if column.lower() == tablepkcolumn[0].lower():
                                if PKdf.shape[0] >= 1:
                                    flag = 0
                                    while flag == 0:
                                        syn_value = self.faker_obj.generate_random_number(
                                            attribute_value, constraints, source_column, tokenization_type)
                                        if syn_value[0] not in PKdf.to_list():
                                            if new_data:
                                                if syn_value[0] not in new_data:
                                                    flag = 1
                                            else:
                                                flag = 1
                        else:
                            syn_value = self.faker_obj.generate_random_number(
                                attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.random_letters.value:
                    syn_value = self.faker_obj.generate_random_letter(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.random_alpha_numeric.value:
                    syn_value = self.faker_obj.random_alpha_numeric(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.license_plate.value:
                    syn_value = self.faker_obj.generate_license_plate(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.job.value:
                    syn_value = self.faker_obj.generate_job(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.personal_email.value:
                    syn_value = self.faker_obj.generate_personal_email(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.company_email.value:
                    syn_value = self.faker_obj.generate_company_email(
                        attribute_value, source_column, tokenization_type)
                elif column_strategy == strategy.ipv4_address.value:
                    syn_value = self.faker_obj.generate_ipv4_address(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.ipv6_address.value:
                    syn_value = self.faker_obj.generate_ipv6_address(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.device_address.value:
                    syn_value = self.faker_obj.generate_device_address(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.domain_name.value:
                    syn_value = self.faker_obj.generate_domain_name(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.credit_card.value:
                    syn_value = self.faker_obj.generate_credit_card(
                        attribute_value, constraints, source_column, tokenization_type)
                    if not is_file:
                        if PKdf.shape[0] >= 1:
                            flag = 0
                            while flag == 0:
                                syn_value = self.faker_obj.generate_credit_card(
                                    attribute_value, constraints, source_column, tokenization_type)
                                if syn_value[0] not in PKdf.to_list():
                                    if new_data:
                                        if syn_value[0] not in new_data:
                                            flag = 1
                                    else:
                                        flag = 1
                    new_value = syn_value[0]
                elif column_strategy == strategy.credit_card_type.value:
                    syn_value = self.faker_obj.generate_credit_card_type(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.credit_card_expiry_date.value:
                    syn_value = self.faker_obj.generate_credit_card_expiry_date(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.bank_account.value:
                    syn_value = self.faker_obj.generate_bank_account(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.swift_code.value:
                    syn_value = self.faker_obj.generate_swift_code(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.company_name.value:
                    syn_value = self.faker_obj.generate_company_name(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.barcode.value:
                    syn_value = self.faker_obj.generate_barcode(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.color.value:
                    syn_value = self.faker_obj.generate_color(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.land_coordinates.value:
                    syn_value = self.faker_obj.generate_land_coordinates(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.currency.value:
                    syn_value = self.faker_obj.generate_currency(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.date_time.value:
                    syn_value = self.faker_obj.generate_date_time(
                        attribute_value, source_column, constraints, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.year.value:
                    syn_value = self.faker_obj.generate_year(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.month_number.value:
                    syn_value = self.faker_obj.generate_month(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.day_number.value:
                    syn_value = self.faker_obj.generate_day_number(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.personal_profile.value:
                    syn_value = self.faker_obj.generate_personal_profile(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.checksum.value:
                    syn_value = self.faker_obj.checksum(
                        attribute_value, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.date_number.value:
                    syn_value = self.faker_obj.generate_date_number(
                        attribute_value, constraints, dependent_fields, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.regex_pattern.value:
                    syn_value = self.faker_obj.generate_regs(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.list.value:
                    syn_value = self.faker_obj.control_list(
                        attribute_value, constraints, source_column, tokenization_type)
                    new_value = syn_value[0]
                elif column_strategy == strategy.list_auto.value:
                    syn_value = list_auto_func(
                        (attribute_value, i), constraints, source_column, tokenization_type, is_new=True)
                    new_value = syn_value[0]
                elif column_strategy == strategy.said.value:
                    syn_value = self.faker_obj.ZA_generate_said(
                        attribute_value, source_column, dependent_fields, None, tokenization_type)
                    new_value = syn_value[0]

                else:
                    if row_count > 1:
                        rn = random.randrange(1, row_count)
                        while True:
                            if column+"_destination_col" in sdf.columns:
                                new_value = sdf[column +
                                                "_destination_col"][rn]
                                break
                            else:
                                new_value = sdf[column][rn]
                                break
                    else:
                        new_value = " "
                new_data.append(new_value)
            df[column] = new_data

        # df_nn
        return df


def create_biglist_for_listauto(df, col_name, locale):
    df_col = pd.DataFrame()

    level, lengths, flatten_ = decompose_and_get_level(df[col_name].to_list())

    # lengths = df[col_name].apply(len).to_list()
    # flatten_ =

    df_col[col_name] = flatten_[:10]
    detected_stretegy = get_semantic_from_df(df_col, semantic_threshold=0.6)
    _, stretegy = list(detected_stretegy.items())[0]
    if "Random Number" in stretegy[1] or "Random Letters" in stretegy[1]:
        return regenerate_nested_list(lengths, flatten_, level)
    else:
        sd = SyntheticDataGenerator(locale=locale)
        stretegy_id = id_map[stretegy[1]]
        new_data = []
        for od in flatten_:
            nv = sd.generate_syn_data(
                od, stretegy_id, "{}", None, col_name, None)[0]

            new_data.append(nv)

        return regenerate_nested_list(lengths, new_data, level)