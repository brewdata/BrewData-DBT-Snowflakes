
import pandas as pd
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'Lib'))
from faker import Faker
import os
from utils import *
# from nogan_synthetic_data_generator import NoGranSyntheticDataGenerator
from synthetic_data_generator import SyntheticDataGenerator

class File_SyntheticData:
    def __init__(self, locale=None):
        self.locale=locale
        self.file_path=None
        self.xsd_file_path=None
        self.file_content=pd.DataFrame()
        self.synthetic_file_content=pd.DataFrame()
        self.file_extension=None
        self.file_name=None
        self.column_config=None
        self.row_limit=None
        self.bias=None
        self.faker=None
        self.xsd=None
        if locale:
            self.faker = Faker(f'{locale}')

    def set_locale(self, locale):
        self.locale=locale
    
    def get_locale(self):
        return self.locale
    
    def set_file_path(self, file_path):
        
        file_split = os.path.splitext(file_path)
        self.file_extension = file_split[1]
        if file_split[0].find("/") !=-1:
            fsplit = file_split[0].split("/")
        else:
            fsplit = file_split[0].split("\\")
        if self.file_extension =='xsd':
            self.xsd_file_path=file_path
        else:
            self.file_path=file_path
            self.file_name =  fsplit[len(fsplit)-1]


    def get_file_path(self):
        return self.file_path
    
    def load_file(self,file_path):
        file_split = os.path.splitext(file_path)
        self.file_extension = file_split[1]
        if file_split[0].find("/") !=-1:
            fsplit = file_split[0].split("/")
        else:
            fsplit = file_split[0].split("\\")
        self.file_name =  fsplit[len(fsplit)-1]

        if file_split[1]=='.csv':
            self.file_content = pd.read_csv(file_path)
        elif file_split[1]=='.xls' or file_split[1]=='.xlsx':
            self.file_content = pd.read_excel(file_path)
        elif file_split[1]=='.json':
            self.file_content = pd.read_json(file_path)
        elif file_split[1]=='.xml':
            self.file_content = pd.read_xml(file_path)
        else:
            self.xsd = pd.read_csv(file_path, header = None)

    def show_file_content(self):
        print(self.file_content)
    
    def get_synthetic_file_content(self):
        return self.synthetic_file_content
    
    def set_column_config(self, config):
        self.column_config = config
    
    def get_column_config(self):
        return self.column_config
    
    def set_row_limit(self, limit):
        self.row_limit = limit
    
    def get_row_limit(self):
        return self.row_limit
    
    def get_column_list(self):
        return self.file_content.columns.to_list()

    def get_row_count(self):
        return self.file_content.shape[0]
    
    def get_file_content(self):
        return self.file_content
    
    # "D:/work/BruData/PythonTesting/personal_data2.json"
    def write_to_file(self, file_path):
        file_split = os.path.splitext(file_path)
        # self.file_extension = file_split[1]
        if file_split[0].find("/") !=-1:
            fsplit = file_split[0].split("/")
        else:
            fsplit = file_split[0].split("\\")
        # self.file_name =  fsplit[len(fsplit)-1]
        if file_split[1]=='.csv':
            self.file_content.to_csv(file_path, index=False)
        if file_split[1]=='.xls' or file_split[1]=='.xlsx':
            self.file_content.to_excel(file_path, index=False) 
        if file_split[1]=='.json':
            self.file_content.to_json(file_path)
        if file_split[1]=='.xml':
            self.file_content.to_xml(file_path)
            
    # config=[{"columns_config":[{"source_column": "birthdate","pattern":None, "pattern_id":None, "strategy_id":76, "dependent_fields":[] , "tokenization_type": "NA"}]}]
    def test_syntehic_single_column(self,file_path,config,locale='en-US'):
        if file_path and config:
            try:
                self.set_file_path(file_path)
                self.set_column_config(config['columns_config'][0])
                self.set_locale(locale)
                self.set_row_limit(1)
                config = self.column_config
                source_column = config['source_column']
                destination_column = config['source_column']
                tokenization_type = config['tokenization_type']
                strategy_id = config['strategy_id']
                pattern_id = config['pattern_id']
                dependent_fields = config['dependent_fields']
                pattern = config['pattern']
                if self.file_extension == '.xml':
                    if int(config['is_xsd']):
                        self.xsd = self.load_file(self.file_path)
                        flag = validate_xml(self.file_content, self.xsd)
                        if not flag:
                            raise Exception(
                                'XML Schema Definition does not match XML uploaded')
                self.load_file(self.file_path)
                if pattern:
                    columnlets_pattern = pattern['columnlets_pattern']
                    for col_pattern in columnlets_pattern:
                        if col_pattern:
                            dependent_fields = col_pattern['dependent_fields']
                sdg = NoGranSyntheticDataGenerator()
                self.file_content = self.file_content.iloc[:self.row_limit]
                df = self.file_content

                df, all_dep,_ = sdg.generate_syn_data_new(source_column, destination_column, tokenization_type,
                                                self.file_content, strategy_id, pattern_id, dependent_fields, pattern, self.locale, True)
                df = sdg.calculate_dependent_fields(df, [all_dep])
                
                df = df.fillna("")
                if source_column.lower().find('zip') != -1 or source_column.lower().find('postal') != -1:
                    if str(df[source_column + '_source_col'].dtype) == 'float64':
                        df[source_column + '_source_col'] = df[source_column +
                                                                '_source_col'].astype('int')
                self.synthetic_file_content = df
                self.synthetic_file_content[source_column]=self.synthetic_file_content[f"{source_column}_destination_col"]

                self.synthetic_file_content=self.synthetic_file_content[self.get_column_list()]  
            except Exception as e:
                print(e)
        else:
            print('Missing parameters, parameter like file_path,column_config')

    # config=[{"columns_config":[{"source_column": "birthdate","pattern":None, "pattern_id":1, "strategy_id": None, "dependent_fields":[] , "tokenization_type": "NA"},
    #                            {"source_column": "phone","pattern":None, "pattern_id":None, "strategy_id": 9, "dependent_fields":[] , "tokenization_type": "NA"}]}]
    def start_synthetic(self, df, config, locale='en-US', limit=10, table_data=None, bias=None):
        
        if config:
            try: 
                self.file_content = df
                self.set_column_config(config['columns_config'])
                self.set_locale(locale)
                # if self.file_extension == '.xml':
                #     if int(config['is_xsd']):
                #         self.xsd = self.load_file(self.file_path)
                #         flag = validate_xml(self.file_content, self.xsd)
                #         if not flag:
                #             raise Exception(
                #                 'XML Schema Definition does not match XML uploaded')
                # self.load_file(self.file_path)
                if limit==None:
                    self.set_row_limit(self.file_content.shape[0])
                else:
                    self.set_row_limit(limit)
                sdg = SyntheticDataGenerator()
                self.file_content = self.file_content.iloc[:self.row_limit]
                
                is_test=True
                before,after = sdg.generate_data_from_job_file(self.file_content,
                    self.column_config, is_test, self.row_limit,self.file_extension,table_data,self.locale,bias)
                self.file_content=before
                self.synthetic_file_content=after
            except Exception as e:
                print(e)
        else:
            print('Missing parameters, parameter like file_path,column_config')



