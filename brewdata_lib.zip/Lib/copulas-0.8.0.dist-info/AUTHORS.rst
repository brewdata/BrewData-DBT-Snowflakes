See: https://github.com/sdv-dev/Copulas/graphs/contributors
