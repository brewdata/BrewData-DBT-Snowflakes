import base64
import itertools
from math import ceil
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.io as pio
import io

from .. import utils

LABEL_THRESH = 5

def distr_plot(
    df: pd.DataFrame,
    target_attr: str,
    groups: Sequence[Union[Mapping[str, List[Any]], pd.Series]],
    attr: str = None,
    labels: List[Any] = None,
    distr_type: Optional[str] = None,
    show_hist: Optional[bool] = None,
    show_curve: Optional[bool] = None,
    shade: bool = True,
    normalize: bool = False,
    cmap: Optional[Sequence[Tuple[float, float, float]]] = None,
    ax: Optional[go.Figure] = None,
    row: int = 1,
    col: int = 1,
    NUM: int = 1
) -> go.Figure:
    """Plot the distribution of the groups with respect to the target attribute using Plotly.

    Args:
        df (pd.DataFrame):
            The input dataframe.
        target_attr (str):
            The target attribute.
        groups (Sequence[Union[Mapping[str, List[Any]], pd.Series]]):
            A list of groups of interest. Each group can be a mapping / dict from attribute to value or
            a predicate itself, i.e. pandas series consisting of bools which can be used as a predicate
            to index a subgroup from the dataframe.
            Examples: {"Sex": ["Male"]}, df["Sex"] == "Female"
        distr_type (Optional[str]):
            The type of distribution of the target attribute. Can take values from
            ["categorical", "continuous", "binary", "datetime"]. If None, the type of
            distribution is inferred based on the data in the column. Defaults to None.
        show_hist (Optional[bool], optional):
            Shows the histogram if True. Defaults to True if the data is categorical or binary.
        show_curve (Optional[bool], optional):
            Shows a KDE if True. Defaults to True if the data is continuous or a date.
        shade (bool, optional):
            Shades the curve if True. Defaults to True.
        normalize (bool, optional):
            Normalizes the counts so the sum of the bar heights is 1. Defaults to False.
        cmap (Optional[Sequence[Tuple[float, float, float]]], optional):
            A sequence of RGB tuples used to colour the histograms. If None, Plotly's default palette
            will be used. Defaults to None.
        ax (Optional[go.Figure], optional):
            A Plotly figure to plot the distribution on. Defaults to None.

    Returns:
        go.Figure:
            The Plotly figure containing the plot.

    Examples:
        >>> df = pd.read_csv("datasets/compas.csv")
        >>> g1 = {"Ethnicity": ["African-American"]}
        >>> g2 = {"Ethnicity": ["Caucasian"]}
        >>> distr_plot(df, "RawScore", [g1, g2])
    """
    if ax is None:
        n_ax = go.Figure()

    preds = utils.get_predicates_mult(df, groups)

    cmap = cmap or px.colors.qualitative.Alphabet
    palette = itertools.cycle(cmap)

    column = utils.infer_dtype(df[target_attr])

    if distr_type is None:
        distr_type = utils.infer_distr_type(column).value

    if show_hist is None:
        show_hist = distr_type in ["categorical", "binary"]

    if show_curve is None:
        show_curve = distr_type in ["continuous", "datetime"]

    kwargs: Dict[str, Any] = {}
    if not show_hist:
        # To hide the histogram, you can simply not add it to the figure
        pass

    if normalize:
        kwargs["stat"] = "probability"

    if distr_type == "continuous":
        _, bins = utils.zipped_hist((df[target_attr],), ret_bins=True, distr_type=distr_type)
    elif distr_type == "datetime":
        bins = utils.fd_opt_bins(column)  # TODO: Look at Plotly log scaling in more detail
    elif column.dtype in ["int64", "float64"]:
        bins = np.arange(column.min(), column.max() + 1.5) - 0.5
        # Plotly doesn't support setting ticks directly on histograms like Matplotlib, so you may need to adjust here
    else:
        bins = "auto"

    # Create a trace for each group
    for pred, name in zip(preds, labels):
        trace = go.Histogram(
            x=column[pred],
            histnorm="probability" if normalize else "",
            opacity=0.7,
            name=name,  # You can set the name to be the group label
            marker=dict(color=next(palette)),
            legendgroup=f'{NUM}',
            legendgrouptitle_text=attr
        )
        if ax is None:
            n_ax.add_trace(trace)
        else:
            ax.add_trace(trace, row=row, col=col)


    if shade and not show_hist:
        # You can handle shading by adjusting the trace properties
        pass
    
    if ax is None:
        ax = n_ax
    ax.update_layout(
        xaxis_title=target_attr,
        yaxis_title="Probability" if normalize else "Frequency",
        legend_title="Groups",
        barmode="overlay",  # Overlay histograms
    )
    return ax


def attr_distr_plot(
    df: pd.DataFrame,
    target_attr: str,
    attr: str,
    distr_type: Optional[str] = None,
    attr_distr_type: Optional[str] = None,
    max_quantiles: int = 8,
    separate: bool = False,
    show_hist: Optional[bool] = None,
    show_curve: Optional[bool] = None,
    shade: bool = True,
    normalize: bool = False,
    cmap: Optional[List[Tuple[float, float, float]]] = None,
    ax: Optional[make_subplots] = None,
    row: int = 1,
    col: int = 1,
    NUM: int = 1,
) -> Optional[make_subplots]:
    """Plot the distribution of the target attribute with respect to all the unique values in the column `attr`.

    Args:
        df (pd.DataFrame):
            The input dataframe.
        target_attr (str):
            The target attribute.
        attr (str):
            The attribute whose values' distributions are to be plotted.
        distr_type (Optional[str], optional):
            The type of distribution of the target attribute. Can take values from
            ["categorical", "continuous", "binary", "datetime"]. If None, the type of
            distribution is inferred based on the data in the column. Defaults to None.
        attr_distr_type (Optional[str], optional):
            The type of distribution of `attr`. Can be "categorical", "continuous", or "datetime".
            If None, the type of distribution is inferred based on the data in the column.
            Defaults to None.
        max_quantiles (int, optional):
            The maximum number of quantiles to use for continuous data. Defaults to 8.
        separate (bool, optional):
            Separate into multiple plots (subplot). Defaults to False.
        show_hist (Optional[bool], optional):
            Shows the histogram if True. Defaults to True if the data is categorical or binary.
        show_curve (Optional[bool], optional):
            Shows a KDE if True. Defaults to True if the data is continuous or a date.
        shade (bool, optional):
            Shades the curve if True. Defaults to True.
        normalize (bool, optional):
            Normalizes the counts so the sum of the bar heights is 1. Defaults to False.
        cmap (Optional[List[Tuple[float, float, float]]], optional):
            A list of RGB tuples used to color the histograms. If None, Plotly's default palette will be used.
            Defaults to None.
        ax (Optional[sp.make_subplots], optional):
            A subplot object to plot the figures on. Defaults to None.

    Returns:
        Optional[sp.make_subplots]:
            The Plotly subplot object containing the plots if `separate` is False, otherwise None.

    Examples:
        >>> df = pd.read_csv("datasets/compas.csv")
        >>> attr_distr_plot(df, "RawScore", "Ethnicity")
        >>> plt.show()
    """

    if target_attr == attr:
        raise ValueError("A sensitive attribute cannot be a decision attribute as well, please select another attribute.")

    df_ = df[[attr, target_attr]].copy()

    column = utils.infer_dtype(df_[attr])

    if distr_type is None:
        distr_type = utils.infer_distr_type(df_[target_attr]).value

    if attr_distr_type is None:
        attr_distr_type = utils.infer_distr_type(column).value

    # Bin data
    if attr_distr_type == "continuous" or attr_distr_type == "datetime":
        df_.loc[:, attr] = utils._bin_as_string(column, attr_distr_type, max_bins=max_quantiles)

    # Values ordered by counts in order for overlay to work well.
    unique_values = df_[attr].dropna().value_counts().keys()

    labels = ['All'] + [str(val) for val in unique_values]
    groups = [pd.Series([True] * len(df_))] + [(df_[attr] == val) for val in unique_values]

    if separate:
        n = len(groups)
        subplot_titles = [f"Subplot {i + 1}" for i in range(n)]
        fig = make_subplots(rows=1, cols=n, subplot_titles=subplot_titles, shared_yaxes=True)

        for i, (group, title) in enumerate(zip(groups, labels)):
            fig.add_trace(go.Histogram(x=df_[target_attr][group], name=title), row=1, col=i + 1)

        fig.update_layout(
            title_text="Attribute Distribution Plots",
            xaxis_title=target_attr,
            yaxis_title="Frequency",
        )

        return fig

    # if distr_type == "binary":
    #     fig = go.Figure()

    #     for group, label, color in zip(groups, labels, cmap):
    #         counts = df_[target_attr][group].value_counts(normalize=normalize)
    #         fig.add_trace(
    #             go.Bar(
    #                 x=counts.index,
    #                 y=counts.values,
    #                 name=label,
    #                 marker=dict(color=color),
    #             )
    #         )

    #     fig.update_layout(
    #         title=f'{attr.capitalize()} Distribution Plot'
    #     )

    #     return fig

    fig = distr_plot(
        df_,
        target_attr,
        groups,
        attr=attr,
        labels=labels,
        distr_type=distr_type,
        show_hist=show_hist,
        show_curve=show_curve,
        shade=shade,
        normalize=normalize,
        cmap=cmap,
        ax=ax,
        row=row,
        col=col,
        NUM=NUM
    )

    return fig


def _shade_area(fig: go.Figure, cmap: Sequence[Tuple[float, float, float]], alpha: float = 0.3):
    """Shade area under all lines in Plotly figure."""

    palette = itertools.cycle(cmap)
    for trace in fig.data:
        if isinstance(trace, go.Scatter):
            x = trace.x
            y = trace.y
            fill_color = next(palette)
            fill_below_trace = go.Scatter(x=x, y=y, fill='tozeroy', fillcolor=fill_color, mode='none', name=trace.name)
            fig.add_trace(fill_below_trace)



def mult_distr_plot(
    df: pd.DataFrame,
    target_attr: str,
    attrs: Sequence[str],
    figsize: Optional[Tuple[int, int]] = None,
    max_width: int = 3,
    distr_type: Optional[str] = None,
    attr_distr_types: Optional[Mapping[str, str]] = None,
    max_quantiles: int = 8,
    show_hist: Optional[bool] = None,
    show_curve: Optional[bool] = None,
    shade: bool = True,
    normalize: bool = False,
    cmap: Optional[Sequence[Tuple[float, float, float]]] = None,
    return_mode: str = "html"
):
    """Plot the distribution of the all values for each of the unique values in the column `attr`
    with respect to the target attribute using Plotly.

    Args:
        df (pd.DataFrame):
            The input dataframe.
        target_attr (str):
            The target attribute.
        attrs (Sequence[str]):
            The attributes whose value distributions are to be plotted.
        figsize (Optional[Tuple[int, int]], optional):
            The size of each figure if `separate` is True. Defaults to (6, 4).
        max_width (int, optional):
            The maximum amount of figures. Defaults to 3.
        distr_type (Optional[str], optional):
            The type of distribution of the target attribute. Can take values from
            ["categorical", "continuous", "binary", "datetime"]. If None, the type of
            distribution is inferred based on the data in the column. Defaults to None.
        attr_distr_types (Optional[Mapping[str, str]], optional):
            The types of distribution of the attributes in `attrs`. Passed as a mapping
            from attribute name to corresponding distribution type.
            Can take values from ["categorical", "continuous", "binary", "datetime"].
            If None, the type of distribution of all sensitive attributes are inferred
            based on the data in the respective columns. Defaults to None.
        max_quantiles (int, optional):
            The maximum amount of quantiles to use for continuous data. Defaults to 8.
        show_hist (Optional[bool], optional):
            Shows the histogram if True. Defaults to True if the data is categorical or binary.
        show_curve (Optional[bool], optional):
            Shows a KDE if True. Defaults to True if the data is continuous or a date.
        shade (bool, optional):
            Shades the curve if True. Defaults to True.
        normalize (bool, optional):
            Normalizes the counts so the sum of the bar heights is 1. Defaults to False.
        cmap (Optional[Sequence[Tuple[float, float, float]]], optional):
            A sequence of RGB tuples used to colour the histograms. If None, Plotly's default palette
            will be used. Defaults to None.

    Examples:
        >>> df = pd.read_csv("datasets/compas.csv")
        >>> mult_distr_plot(df, "RawScore", ["Ethnicity", "Sex", "MaritalStatus", "Language", "DateOfBirth"])
    """
    attr_distr_types = attr_distr_types or {}

    if figsize is None:
        figsize = 6, 4

    n = len(attrs)
    r = ceil(n / max_width)
    c = min(n, max_width)
    fig = make_subplots(rows=r, cols=c, subplot_titles=attrs, shared_yaxes=True)
    row = 1
    col = 1
    for i, attr in enumerate(attrs):
        attr_distr_type = attr_distr_types[attr] if attr in attr_distr_types else None
        attr_distr_plot(
            df,
            target_attr,
            attr,
            distr_type=distr_type,
            attr_distr_type=attr_distr_type,
            max_quantiles=max_quantiles,
            show_hist=show_hist,
            show_curve=show_curve,
            shade=shade,
            normalize=normalize,
            cmap=cmap,
            ax=fig,
            row=row,
            col=col,
            NUM=i+1
        )
        
        col += 1
        if col == c+1:
            col = 1
            row += 1

    # fig.update_layout(
    #     height=figsize[1] * r,
    #     width=figsize[0] * c,
    #     legend_tracegroupgap = 180,
    #     showlegend=True,
    #     legend=dict(title="Attributes"),
    #     grid=dict(rows=r, columns=c),
    #     margin=dict(t=0.03, b=0.07),
    # )
    buffer = io.StringIO()
    if return_mode == 'html':
        buffer = io.StringIO()
        pio.write_html(fig, buffer)
        r_html = buffer.getvalue()
        return r_html
    elif return_mode == 'png':
        buffer = io.BytesIO()
        fig.write_image(buffer, format='png', engine='kaleido')
        buffer.seek(0)

        # Convert buf image to base64 string
        img = base64.b64encode(buffer.getvalue()).decode("utf-8")
        return img
    else:
        return fig