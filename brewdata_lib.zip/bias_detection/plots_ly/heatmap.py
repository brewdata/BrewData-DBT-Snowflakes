import plotly.graph_objects as go
import pandas as pd
import numpy as np
from typing import Callable, List, Optional

from ..metrics import correlation, unified

def two_column_heatmap(
    df: pd.DataFrame,
    num_num_metric: Callable[[pd.Series, pd.Series], float] = correlation.pearson,
    cat_num_metric: Callable[[pd.Series, pd.Series], float] = correlation.kruskal_wallis,
    cat_cat_metric: Callable[[pd.Series, pd.Series], float] = correlation.cramers_v,
    columns_x: Optional[List[str]] = None,
    columns_y: Optional[List[str]] = None,
):
    """This function creates a correlation heatmap out of a dataframe, using user provided or default correlation
    metrics for all possible types of pairs of series (i.e. numerical-numerical, categorical-numerical,
    categorical-categorical).

    Args:
        df (pd.DataFrame):
            The dataframe used for computing correlations and producing a heatmap.
        num_num_metric (Callable[[pd.Series, pd.Series], float], optional):
            The correlation metric used for numerical-numerical series pairs. Defaults to Pearson's correlation
            coefficient.
        cat_num_metric (Callable[[pd.Series, pd.Series], float], optional):
            The correlation metric used for categorical-numerical series pairs. Defaults to Kruskal-Wallis' H Test.
        cat_cat_metric (Callable[[pd.Series, pd.Series], float], optional):
            The correlation metric used for categorical-categorical series pairs. Defaults to corrected Cramer's V
            statistic.
        columns_x (Optional[List[str]]):
            The sensitive dataframe column names that will be used in generating the correlation heatmap.
        columns_y (Optional[List[str]]):
            The non-sensitive dataframe column names that will be used in generating the correlation heatmap.
    """

    if columns_x is None:
        columns_x = df.columns

    if columns_y is None:
        columns_y = df.columns

    corr_matrix = unified.correlation_matrix(
        df, num_num_metric, cat_num_metric, cat_cat_metric, columns_x, columns_y
    ).round(2)

    fig = go.Figure(data=go.Heatmap(
        z=corr_matrix.values,
        x=columns_x,
        y=columns_y,
        colorscale="Viridis",  # You can choose any color scale you prefer
        colorbar=dict(title="Correlation"),
    ))

    fig.update_layout(
        title="Correlation Heatmap",
        xaxis=dict(tickangle=45),
        xaxis_title="Non-sensitive Columns",
        yaxis_title="Sensitive Columns",
    )

    fig.show()

# Usage
# Replace with your actual data and metrics
df = pd.DataFrame()  # Replace with your dataframe
two_column_heatmap(df)