"""Machine Learning Detection metrics that work on multiple tables."""
